extends CharacterBody2D

# ─────────────────────────────────────────────
#  PLAYER CONTROLLER
# ─────────────────────────────────────────────

const VisualEffects = preload("res://block-scripts/VisualEffects.gd")

# ── Identity ──────────────────────────────────
@export_group("Player Settings")
@export var player_id:    int   = 1
@export var player_color: Color = Color.WHITE

# ── Input actions (set programmatically) ──────
@export_group("Input Actions")
@export var jump_action:    String = "ui_accept"
@export var left_action:    String = "ui_left"
@export var right_action:   String = "ui_right"
@export var charge_action:  String = "ui_down"
@export var gravity_action: String = "gravity_skill"
var _down_action: String = "p1_down"

# ── Movement ──────────────────────────────────
@export_group("Movement")
@export var speed:             float = 300.0
@export var acceleration:      float = 30.0
@export var friction:          float = 10.0
@export var jump_height:       float = 500.0
@export var max_jumps:         int   = 2
@export var jump_force_radius:    float = 100.0
@export var jump_force_strength:  float = 300.0
@export var show_force_radius: bool  = true

# ── Gravity field ─────────────────────────────
@export_group("Gravity Field")
@export var gravity_field_radius:     float = 200.0
@export var gravity_field_strength:   float = 900.0
@export var upward_lift_force:        float = 1200.0
@export var platform_gather_force:    float = 400.0
@export var platform_radius:          float = 60.0
@export var player_lift_multiplier:   float = 80.0
@export var max_fragments_for_lift:   int   = 6
@export var fragment_push_force:      float = 200.0
@export var push_distance_threshold:  float = 80.0
@export var gravity_field_cooldown:   float = 5.0
@export var gravity_field_max_duration: float = 1.0
@export var show_gravity_field:       bool  = true

# ── Charged jump ──────────────────────────────
@export_group("Charged Jump")
@export var max_charge_time:  float = 1.5
@export var max_charge_jump:  float = 800.0
@export var fast_fall_force:  float = 2000.0
@export var max_fall_speed:   float = 3000.0

# ── Runtime state ─────────────────────────────
var gravity: float = ProjectSettings.get_setting("physics/2d/default_gravity")

var jumps_remaining:  int   = 0
var _was_on_floor:    bool  = true
var is_dead:          bool  = false

var is_charging_jump: bool  = false
var charge_time:      float = 0.0
var charge_visual            = null

var gravity_field_active:          bool  = false
var gravity_field_cooldown_timer:  float = 0.0
var gravity_field_duration_timer:  float = 0.0
var gravity_field_visual                 = null

var attracted_fragments:       Array = []
var fragment_original_properties: Dictionary = {}

var _movement_lines = null   # MovementLines instance, child of player

signal player_died(player_id: int)

# ─────────────────────────────────────────────
#  INITIALISATION
# ─────────────────────────────────────────────

func _ready() -> void:
	add_to_group("player")
	_setup_player_configuration()
	_setup_player_visual()
	_movement_lines = VisualEffects.MovementLines.new()
	add_child(_movement_lines)

func _setup_player_configuration() -> void:
	var prefix := "p%d" % player_id
	jump_action    = prefix + "_jump"
	left_action    = prefix + "_left"
	right_action   = prefix + "_right"
	_down_action   = prefix + "_down"
	charge_action  = prefix + "_charge"
	gravity_action = prefix + "_gravity"

	match player_id:
		1:
			player_color = Color(0.8, 0.2, 0.2)
			add_to_group("player1")
		2:
			player_color = Color(0.2, 0.8, 0.2)
			add_to_group("player2")

func _setup_player_visual() -> void:
	var rect := $ColorRect
	if not rect:
		return

	rect.color = player_color

	var shader := Shader.new()
	shader.code = """
shader_type canvas_item;

uniform float outline_width : hint_range(0.01, 0.12) = 0.06;
uniform vec4  shadow_color  : source_color = vec4(0.0, 0.0, 0.0, 0.35);

void fragment() {
	float dist    = distance(UV, vec2(0.5));
	float fill    = smoothstep(0.5, 0.485, dist);
	float outline = smoothstep(0.5, 0.485, dist - outline_width) - fill;

	// Two-tone flat cel shade — hard split, no gradient
	float shadow  = step(0.55, UV.y);
	vec4 base     = COLOR;
	base           = mix(base, vec4(shadow_color.rgb, base.a), shadow * shadow_color.a);

	COLOR   = mix(base, vec4(0.0, 0.0, 0.0, 1.0), outline);
	COLOR.a = fill;
}
"""
	var mat := ShaderMaterial.new()
	mat.shader = shader
	mat.set_shader_parameter("outline_width", 0.06)
	mat.set_shader_parameter("shadow_color",  Color(0.0, 0.0, 0.0, 0.35))
	rect.material = mat

# ─────────────────────────────────────────────
#  PHYSICS PROCESS
# ─────────────────────────────────────────────

func _physics_process(delta: float) -> void:
	if is_dead:
		return

	# 1. Timers
	if gravity_field_cooldown_timer > 0.0:
		gravity_field_cooldown_timer -= delta

	if gravity_field_active:
		gravity_field_duration_timer += delta
		if gravity_field_duration_timer >= gravity_field_max_duration:
			deactivate_gravity_field()

	# 2. Vertical — gravity, lift, field hover
	if is_on_floor():
		jumps_remaining = max_jumps
	else:
		var lift := _calculate_fragment_lift_force()
		velocity.y += (gravity - lift) * delta

		if gravity_field_active:
			if _is_standing_on_platform():
				velocity.y = -400.0
			elif velocity.y > 0.0:
				velocity.y *= 0.85

	# 3. Abilities
	_handle_charged_jump(delta)

	if Input.is_action_just_pressed(jump_action) and jumps_remaining > 0 and not is_charging_jump:
		velocity.y = -jump_height
		jumps_remaining -= 1
		_emit_jump_force()
		if show_force_radius:
			_create_force_wave_effect()

	if Input.is_action_pressed(gravity_action) and _can_activate_gravity_field():
		if not gravity_field_active:
			activate_gravity_field()
	elif Input.is_action_just_released(gravity_action) and gravity_field_active:
		deactivate_gravity_field()

	if gravity_field_active:
		_update_gravity_field()

	# 4. Horizontal
	var direction := Input.get_axis(left_action, right_action)
	if has_meta("controls_reversed"):
		direction = -direction

	if direction != 0.0:
		velocity.x = move_toward(velocity.x, direction * speed, acceleration * delta * 60.0)
	else:
		velocity.x = move_toward(velocity.x, 0.0, friction * delta * 60.0)

	# 5. Fast fall
	if not is_on_floor() and Input.is_action_pressed(_down_action):
		velocity.y += fast_fall_force * delta
		velocity.y = min(velocity.y, max_fall_speed)

	# 6. Squash & stretch + finalize
	_apply_squash_and_stretch(delta)

	# Feed velocity to movement lines
	if _movement_lines:
		_movement_lines.set_velocity(velocity)

	# Landing impact
	var on_floor_now: bool = is_on_floor()
	if on_floor_now and not _was_on_floor:
		_spawn_landing_impact()

	move_and_slide()

# ─────────────────────────────────────────────
#  SQUASH & STRETCH
# ─────────────────────────────────────────────

func _apply_squash_and_stretch(delta: float) -> void:
	var sprite := $ColorRect
	if not sprite:
		return

	if is_on_floor() and not _was_on_floor:
		sprite.scale = Vector2(1.2, 0.8)
	elif not is_on_floor() and _was_on_floor:
		sprite.scale = Vector2(0.8, 1.2)

	sprite.scale = sprite.scale.lerp(Vector2.ONE, 10.0 * delta)
	_was_on_floor = is_on_floor()

# ─────────────────────────────────────────────
#  DEATH & RESET
# ─────────────────────────────────────────────

func die() -> void:
	if is_dead:
		return
	is_dead = true
	print("Player %d died." % player_id)

	velocity = Vector2.ZERO
	if _movement_lines:
		_movement_lines.set_velocity(Vector2.ZERO)
	deactivate_gravity_field()
	_stop_charge_visual()

	modulate.a = 0.0
	set_collision_layer(0)
	set_collision_mask(0)

	player_died.emit(player_id)

func take_damage(_amount: int) -> void:
	die()

func reset_player() -> void:
	is_dead                    = false
	visible                    = true
	process_mode               = Node.PROCESS_MODE_INHERIT
	velocity                   = Vector2.ZERO
	modulate.a                 = 1.0
	jumps_remaining            = max_jumps
	is_charging_jump           = false
	charge_time                = 0.0
	gravity_field_active       = false
	gravity_field_cooldown_timer  = 0.0
	gravity_field_duration_timer  = 0.0
	attracted_fragments.clear()
	fragment_original_properties.clear()
	_stop_charge_visual()
	if gravity_field_visual:
		gravity_field_visual.queue_free()
		gravity_field_visual = null

# ─────────────────────────────────────────────
#  GRAVITY FIELD
# ─────────────────────────────────────────────

func _can_activate_gravity_field() -> bool:
	return gravity_field_cooldown_timer <= 0.0

func activate_gravity_field() -> void:
	gravity_field_active         = true
	gravity_field_duration_timer = 0.0
	_create_gravity_field_visual()
	_update_attracted_fragments()

func deactivate_gravity_field() -> void:
	gravity_field_active         = false
	gravity_field_cooldown_timer = gravity_field_cooldown
	gravity_field_duration_timer = 0.0

	_push_close_fragments()

	for fragment in attracted_fragments:
		if not is_instance_valid(fragment):
			continue
		fragment.remove_from_group("attracted_to_player")

		if fragment_original_properties.has(fragment):
			var orig: Dictionary = fragment_original_properties[fragment]
			fragment.linear_damp  = orig["linear_damp"]
			fragment.angular_damp = orig["angular_damp"]
			fragment.gravity_scale = orig["gravity_scale"]
			fragment.lock_rotation = orig["lock_rotation"]
			fragment.set_collision_layer(orig["collision_layer"])
			fragment.set_collision_mask(orig["collision_mask"])
		else:
			fragment.linear_damp   = 0.2
			fragment.angular_damp  = 1.0
			fragment.gravity_scale = 0.01
			fragment.lock_rotation = false
			fragment.set_collision_layer(1)
			fragment.set_collision_mask(1)

	attracted_fragments.clear()
	fragment_original_properties.clear()

	if gravity_field_visual:
		gravity_field_visual.queue_free()
		gravity_field_visual = null

func _update_gravity_field() -> void:
	_update_attracted_fragments()
	for fragment in attracted_fragments:
		if is_instance_valid(fragment):
			_apply_gravity_field_to_fragment(fragment)

func _update_attracted_fragments() -> void:
	for fragment in attracted_fragments:
		if is_instance_valid(fragment):
			fragment.remove_from_group("attracted_to_player")
	attracted_fragments.clear()

	var all_nodes: Array = get_tree().get_nodes_in_group("fragments")

	# Fallback: tree scan if group is empty (e.g. during early startup)
	if all_nodes.is_empty():
		_find_fragments_recursive(get_tree().current_scene, all_nodes)

	for fragment in all_nodes:
		if not is_instance_valid(fragment) or not (fragment is RigidBody2D):
			continue
		var dist: float = global_position.distance_to(fragment.global_position)
		if dist <= gravity_field_radius:
			attracted_fragments.append(fragment)
			fragment.add_to_group("attracted_to_player")
			if not fragment_original_properties.has(fragment):
				fragment_original_properties[fragment] = {
					"gravity_scale":    fragment.gravity_scale,
					"linear_damp":      fragment.linear_damp,
					"angular_damp":     fragment.angular_damp,
					"collision_layer":  fragment.collision_layer,
					"collision_mask":   fragment.collision_mask,
					"lock_rotation":    fragment.lock_rotation,
				}

func _find_fragments_recursive(node: Node, list: Array) -> void:
	if node is RigidBody2D and node.name.begins_with("Fragment_"):
		list.append(node)
	for child in node.get_children():
		_find_fragments_recursive(child, list)

func _apply_gravity_field_to_fragment(fragment: RigidBody2D) -> void:
	var platform_center := global_position + Vector2(0.0, 40.0)
	var frag_pos        := fragment.global_position
	var dist_to_platform := platform_center.distance_to(frag_pos)
	var dist_to_player   := global_position.distance_to(frag_pos)
	var very_close       := dist_to_player <= 80.0

	# Always apply upward lift
	fragment.apply_central_force(Vector2(0.0, -upward_lift_force))
	fragment.gravity_scale = 0.0

	if dist_to_platform <= platform_radius:
		# Pull toward platform center
		var toward_platform := (platform_center - frag_pos).normalized()
		fragment.apply_central_force(toward_platform * platform_gather_force)
		fragment.apply_central_force(Vector2(0.0, -upward_lift_force * 1.5))

		fragment.linear_damp  = 15.0 if very_close else 8.0
		fragment.angular_damp = 20.0 if very_close else 10.0
		fragment.lock_rotation = very_close

		if very_close:
			fragment.apply_central_force(Vector2(0.0, -upward_lift_force * 2.0))
			fragment.set_collision_layer(0)
			fragment.set_collision_mask(1)
		else:
			fragment.set_collision_layer(1)
			fragment.set_collision_mask(1)
	else:
		fragment.linear_damp   = 1.5
		fragment.angular_damp  = 1.0
		fragment.lock_rotation = false
		fragment.set_collision_layer(1)
		fragment.set_collision_mask(1)

func _is_standing_on_platform() -> bool:
	var platform_center := global_position + Vector2(0.0, 40.0)
	var count := 0
	for fragment in attracted_fragments:
		if not is_instance_valid(fragment):
			continue
		var fp: Vector2 = fragment.global_position
		if platform_center.distance_to(fp) <= platform_radius \
				and fp.y > global_position.y - 20.0 \
				and fp.y < global_position.y + 80.0:
			count += 1
			if count >= 2:
				return true
	return false

func _calculate_fragment_lift_force() -> float:
	if not gravity_field_active:
		return 0.0
	var platform_center := global_position + Vector2(0.0, 40.0)
	var total := 0.0
	var count := 0
	for fragment in attracted_fragments:
		if not is_instance_valid(fragment):
			continue
		if platform_center.distance_to(fragment.global_position) <= platform_radius + 20.0:
			total += player_lift_multiplier
			count += 1
			if count >= max_fragments_for_lift:
				break
	return total

func _push_close_fragments() -> void:
	for fragment in attracted_fragments:
		if not is_instance_valid(fragment):
			continue
		var dist := global_position.distance_to(fragment.global_position)
		if dist <= push_distance_threshold:
			var dir: Vector2     = (fragment.global_position - global_position).normalized()
			var impulse: Vector2 = dir * fragment_push_force
			impulse.y -= fragment_push_force * 0.3
			fragment.apply_central_impulse(impulse)

func _create_gravity_field_visual() -> void:
	if not show_gravity_field:
		return
	gravity_field_visual = VisualEffects.GravityFieldEffect.new()
	add_child(gravity_field_visual)

# ─────────────────────────────────────────────
#  JUMP FORCE
# ─────────────────────────────────────────────

func _emit_jump_force() -> void:
	var affected: Array = (
		get_tree().get_nodes_in_group("destructible_blocks")
		+ get_tree().get_nodes_in_group("bouncy_blocks")
		+ get_tree().get_nodes_in_group("reverse_blocks")
		+ get_tree().get_nodes_in_group("ice_blocks")
	)

	for block in affected:
		if block.is_in_group("destructible_blocks"):
			if _is_player_on_or_near_block(block):
				block.receive_force(global_position, jump_force_strength)
		else:
			var dist := global_position.distance_to(block.global_position)
			if dist <= jump_force_radius:
				var factor := 1.0 - (dist / jump_force_radius)
				block.receive_force(global_position, jump_force_strength * factor)

	_apply_force_to_fragments(get_tree().get_nodes_in_group("fragments"))

func _is_player_on_or_near_block(block: Node) -> bool:
	var bp: Vector2    = block.global_position
	var half: Vector2  = Vector2(200.0, 40.0)
	var margin: float  = 20.0

	if global_position.x < bp.x - half.x - margin \
			or global_position.x > bp.x + half.x + margin:
		return false

	var vert: float = global_position.y - (bp.y - half.y)
	return vert >= -80.0 and vert <= 20.0

func _apply_force_to_fragments(fragments: Array) -> void:
	for fragment in fragments:
		if not is_instance_valid(fragment):
			continue
		var dist := global_position.distance_to(fragment.global_position)
		if dist > jump_force_radius:
			continue
		var factor: float    = 1.0 - (dist / jump_force_radius)
		var dir: Vector2     = (fragment.global_position - global_position).normalized()
		var impulse: Vector2 = dir * jump_force_strength * factor * 0.3
		if impulse.length() < 30.0:
			impulse = impulse.normalized() * 30.0
		impulse.y -= 20.0
		fragment.angular_velocity += randf_range(-2.0, 2.0)
		fragment.apply_central_impulse(impulse)

func _spawn_landing_impact() -> void:
	var impact = VisualEffects.LandingImpact.new()
	get_parent().add_child(impact)
	impact.global_position = global_position

func _create_force_wave_effect() -> void:
	var wave = VisualEffects.JumpWaveEffect.new()
	get_parent().add_child(wave)
	wave.global_position = global_position

# ─────────────────────────────────────────────
#  CHARGED JUMP
# ─────────────────────────────────────────────

func _handle_charged_jump(delta: float) -> void:
	# Begin charge — is_action_pressed allows holding the button in the air
	# and having the charge start the moment you land
	if Input.is_action_pressed(charge_action) and is_on_floor() and not is_charging_jump:
		is_charging_jump = true
		charge_time      = 0.0
		_create_charge_visual()

	if not is_charging_jump:
		return

	charge_time = min(charge_time + delta, max_charge_time)
	_update_charge_visual()

	if Input.is_action_just_released(charge_action):
		var ratio      := charge_time / max_charge_time
		velocity.y      = -lerp(jump_height, max_charge_jump, ratio)
		jumps_remaining = max_jumps - 1
		_emit_jump_force()
		_create_charged_force_wave(ratio)
		_stop_charge_visual()

func _create_charge_visual() -> void:
	charge_visual = VisualEffects.ChargeEffect.new()
	add_child(charge_visual)

func _update_charge_visual() -> void:
	if charge_visual:
		charge_visual.update_charge(charge_time / max_charge_time)

func _stop_charge_visual() -> void:
	is_charging_jump = false
	charge_time      = 0.0
	if charge_visual:
		charge_visual.queue_free()
		charge_visual = null

func _create_charged_force_wave(charge_ratio: float) -> void:
	var wave = VisualEffects.JumpWaveEffect.new()
	wave.max_radius = 120.0 + charge_ratio * 60.0
	wave.base_color = Color.YELLOW.lerp(Color.ORANGE, charge_ratio) \
		if player_id == 1 else Color.LIME.lerp(Color.GREEN, charge_ratio)
	get_parent().add_child(wave)
	wave.global_position = global_position

# ─────────────────────────────────────────────
#  PUBLIC QUERIES (used by UI / game manager)
# ─────────────────────────────────────────────

func get_gravity_field_cooldown_progress() -> float:
	if gravity_field_cooldown_timer <= 0.0:
		return 1.0
	return 1.0 - (gravity_field_cooldown_timer / gravity_field_cooldown)

func get_jump_force_radius() -> float:
	return jump_force_radius

# ─────────────────────────────────────────────
#  DEBUG DRAW (editor only)
# ─────────────────────────────────────────────

func _draw() -> void:
	if not Engine.is_editor_hint():
		return

	if show_force_radius:
		var c := Color.RED if player_id == 1 else Color.GREEN
		draw_circle(Vector2.ZERO, jump_force_radius, Color(c.r, c.g, c.b, 0.1))
		draw_arc(Vector2.ZERO, jump_force_radius, 0.0, TAU, 32, c, 2.0)

	if show_gravity_field:
		var fc := Color.MAGENTA if player_id == 1 else Color.LIME
		draw_circle(Vector2.ZERO, gravity_field_radius, Color(fc.r, fc.g, fc.b, 0.05))
		draw_arc(Vector2.ZERO, gravity_field_radius, 0.0, TAU, 32, fc, 2.0)
		draw_arc(Vector2.ZERO, push_distance_threshold, 0.0, TAU, 32, Color.YELLOW, 1.0)

		var poff := Vector2(0.0, 40.0)
		draw_circle(poff, platform_radius, Color(0.0, 1.0, 1.0, 0.1))
		draw_arc(poff, platform_radius, 0.0, TAU, 32, Color.CYAN, 2.0)
