extends Node2D

# ─────────────────────────────────────────────
#  BACKGROUND PARTICLES
# ─────────────────────────────────────────────

@export_group("Debris Shards")
@export var shard_count:  int   = 120
@export var shard_color:  Color = Color(0.6, 0.8, 1.0, 0.18)

@export_group("Stars")
@export var star_count:   int   = 80
@export var star_color:   Color = Color(0.85, 0.9, 1.0, 0.55)

@export_group("Embers")
@export var ember_count:  int   = 55
@export var ember_color:  Color = Color(1.0, 0.35, 0.05, 0.7)
@export var ember_color_hot: Color = Color(1.0, 0.75, 0.1, 0.9)

var _shards: Array = []
var _stars:  Array = []
var _embers: Array = []

# Half-sizes of the spawn region
var _hw: float = 600.0   
var _hh: float = 400.0   

var _prev_player_x: float = 0.0

# ─────────────────────────────────────────────
#  INIT
# ─────────────────────────────────────────────

func _ready() -> void:
	# Center the node in the middle of the screen
	var vp := get_viewport_rect()
	position = vp.size / 2
	
	_hw = vp.size.x * 0.6
	_hh = vp.size.y * 0.6

	for i in shard_count: _shards.append(_make_shard(true))
	for i in star_count:  _stars.append(_make_star(true))
	for i in ember_count: _embers.append(_make_ember(true))

# ─────────────────────────────────────────────
#  FACTORIES
# ─────────────────────────────────────────────

func _make_shard(random_pos: bool = false) -> Dictionary:
	return {
		"pos":    Vector2(
			randf_range(-_hw, _hw),
			randf_range(-_hh, _hh) if random_pos else _hh),
		"speed":          randf_range(55.0, 160.0),
		"length":         randf_range(4.0, 18.0),
		"width":          randf_range(0.8, 2.5),
		"drift":          randf_range(-12.0, 12.0),
		"flicker_timer":  randf() * PI,
		"glitchy":        randf() > 0.94,
		"tint":           randf_range(0.85, 1.0),
	}

func _make_star(random_pos: bool = false) -> Dictionary:
	return {
		"pos":    Vector2(
			randf_range(-_hw, _hw),
			randf_range(-_hh, _hh) if random_pos else _hh),
		"size":            randf_range(0.6, 2.2),
		"twinkle_timer":  randf() * TAU,
		"twinkle_speed":  randf_range(0.4, 1.2),
		"parallax_depth": randf_range(0.01, 0.04),
		"drift_y":        randf_range(2.0, 8.0),
	}

func _make_ember(random_pos: bool = false) -> Dictionary:
	return {
		"pos":    Vector2(
			randf_range(-_hw, _hw),
			randf_range(0.0, _hh) if random_pos else _hh),
		"rise_speed":   randf_range(18.0, 65.0),
		"drift_speed":  randf_range(-22.0, 22.0),
		"life":         randf() if random_pos else 0.0,
		"life_speed":   randf_range(0.04, 0.14),
		"size":         randf_range(1.2, 3.5),
		"hot":          randf() > 0.6,
		"wobble":       randf() * TAU,
		"wobble_speed": randf_range(1.5, 4.0),
	}

# ─────────────────────────────────────────────
#  UPDATE
# ─────────────────────────────────────────────

func _process(delta: float) -> void:
	# Get all active players to calculate movement reaction
	var players = get_tree().get_nodes_in_group("player")
	var player_vel_y: float = 0.0
	var dx: float = 0.0
	
	if players.size() > 0:
		# Use the first player for reference movement
		var p = players[0]
		player_vel_y = p.velocity.y
		dx = p.global_position.x - _prev_player_x
		_prev_player_x = p.global_position.x

	var vertical_pull: float = abs(player_vel_y) * 0.08

	_update_shards(delta, vertical_pull)
	_update_stars(delta, dx)
	_update_embers(delta)

	queue_redraw()

func _update_shards(delta: float, vertical_pull: float) -> void:
	for i in _shards.size():
		var p: Dictionary = _shards[i]
		p.flicker_timer += delta * 9.0
		# They fly UP when player falls DOWN
		p.pos.y -= (p.speed + vertical_pull) * delta
		p.pos.x += p.drift * delta * sin(p.flicker_timer)
		if p.pos.y < -_hh:
			_shards[i] = _make_shard(false)

func _update_stars(delta: float, player_dx: float) -> void:
	for i in _stars.size():
		var s: Dictionary = _stars[i]
		s.twinkle_timer += delta * s.twinkle_speed
		s.pos.x -= player_dx * s.parallax_depth
		s.pos.y += s.drift_y * delta
		
		# Wrap horizontally
		if s.pos.x < -_hw: s.pos.x = _hw
		elif s.pos.x > _hw: s.pos.x = -_hw
		
		if s.pos.y > _hh:
			_stars[i] = _make_star(false)

func _update_embers(delta: float) -> void:
	for i in _embers.size():
		var e: Dictionary = _embers[i]
		e.wobble += delta * e.wobble_speed
		e.pos.y  -= e.rise_speed * delta
		e.pos.x  += e.drift_speed * delta * sin(e.wobble)
		e.life   += e.life_speed * delta
		if e.life >= 1.0 or e.pos.y < -_hh:
			_embers[i] = _make_ember(false)

# ─────────────────────────────────────────────
#  DRAW
# ─────────────────────────────────────────────

func _draw() -> void:
	_draw_stars()
	_draw_embers()
	_draw_shards()

func _draw_stars() -> void:
	for s in _stars:
		var twinkle: float = sin(s.twinkle_timer) * 0.35 + 0.65
		var alpha: float   = twinkle * 0.55
		var c := Color(0.85, 0.9, 1.0, alpha)
		var r: float = s.size * twinkle
		if r > 1.4:
			draw_line(s.pos - Vector2(r * 1.6, 0.0), s.pos + Vector2(r * 1.6, 0.0),
				Color(c.r, c.g, c.b, alpha * 0.35), 0.8)
			draw_line(s.pos - Vector2(0.0, r * 1.6), s.pos + Vector2(0.0, r * 1.6),
				Color(c.r, c.g, c.b, alpha * 0.35), 0.8)
		draw_circle(s.pos, r, c)

func _draw_embers() -> void:
	for e in _embers:
		var fade: float = 1.0 - pow(e.life, 2.0)
		var base: Color = ember_color_hot if e.hot else ember_color
		var c := Color(base.r, base.g, base.b, base.a * fade)
		draw_circle(e.pos, e.size * fade, c)
		if e.hot and fade > 0.4:
			draw_circle(e.pos, e.size * 0.4 * fade, Color(1.0, 1.0, 0.8, fade * 0.9))

func _draw_shards() -> void:
	for p in _shards:
		var flicker: float = (sin(p.flicker_timer) * 0.5 + 0.5) if p.glitchy else 1.0
		var c := Color(
			shard_color.r * p.tint,
			shard_color.g * p.tint,
			shard_color.b,
			shard_color.a * flicker)
		var stretch := Vector2(0.0, p.length + abs(p.drift) * 0.18)
		draw_line(p.pos, p.pos + stretch, c, p.width)
		if p.glitchy and flicker > 0.8:
			draw_circle(p.pos, p.width * 1.6, Color(1.0, 1.0, 1.0, 0.35))
