extends Node2D

# ─────────────────────────────────────────────
#  MAP GENERATION  —  Diverse Biomes Edition
# ─────────────────────────────────────────────

@export_group("Map Settings")
@export var map_width: int = 1000
@export var generation_height: float = 10000.0

@export_group("Block Scenes")
@export var destructible_block_scene: PackedScene
@export var regular_block_scene:      PackedScene
@export var bouncy_block_scene:       PackedScene
@export var ice_block_scene:          PackedScene
@export var reverse_block_scene:      PackedScene
@export var moving_platform_scene:    PackedScene

class Biome:
	var name: String
	var height_start: float
	var height_end: float
	var gap_min: float
	var gap_max: float
	var plat_min: float
	var plat_max: float
	var tmpl_weights: Array
	var palette: Dictionary # Now supports multiple block types per biome

	func _init(n, s, e, g_min, g_max, p_min, p_max, tmpl, pal):
		name = n; height_start = s; height_end = e
		gap_min = g_min; gap_max = g_max
		plat_min = p_min; plat_max = p_max
		tmpl_weights = tmpl; palette = pal

var _biomes: Array = []

func _init_biomes() -> void:
	# 1. RUBBLE: Mostly solid ground, occasional crumbling (destructible) or moving parts.
	_biomes.append(Biome.new("Rubble", 0.0, 0.25, 120.0, 160.0, 160.0, 300.0, [50, 20, 15, 5, 10], 
		{"regular": 60, "destructible": 30, "moving": 10}))
	
	# 2. INFERNO: A mix of solid stone and high-energy bouncy "vents."
	_biomes.append(Biome.new("Inferno", 0.25, 0.55, 130.0, 180.0, 140.0, 250.0, [30, 30, 20, 15, 5], 
		{"regular": 40, "bouncy": 30, "destructible": 30}))
	
	# 3. VOID: Slippery, unstable surfaces with gravity-reversing anomalies.
	_biomes.append(Biome.new("Void", 0.55, 0.80, 140.0, 200.0, 120.0, 200.0, [20, 35, 25, 20, 0], 
		{"ice": 40, "reverse": 30, "regular": 30}))
	
	# 4. STORM: High mobility and high risk. Everything moves or slips.
	_biomes.append(Biome.new("Storm", 0.80, 1.0, 150.0, 220.0, 110.0, 180.0, [10, 30, 20, 35, 5], 
		{"moving": 40, "reverse": 30, "ice": 30}))

# ... [Template logic remains the same to keep your structure] ...

func _resolve_block_type(palette: Dictionary, role: String, rng: RandomNumberGenerator) -> String:
	# Contextual priority: Always use Regular for safety/choke points unless the biome is extreme
	if role == "safe" or role == "choke":
		if rng.randf() < 0.8: return "regular"
	
	# Weighted random roll from the biome's mixed palette
	var total = 0
	for v in palette.values(): total += v
	
	var roll = rng.randi_range(0, total - 1)
	var cum = 0
	for k in palette.keys():
		cum += palette[k]
		if roll < cum: return k
	return "regular"

# ─────────────────────────────────────────────
#  CORE GENERATION
# ─────────────────────────────────────────────

var generated_blocks := []
var current_height: float = 0.0
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	_rng.randomize()
	_init_biomes()
	generate_map()

func generate_map() -> void:
	var y: float = 0.0
	while y > -generation_height:
		var depth_frac = abs(y) / generation_height
		var biome = _get_biome_at(depth_frac)
		
		# Build the row
		var tmpl = _pick_template(biome, _rng)
		var platforms = _build_template(tmpl, _rng, biome.plat_min, biome.plat_max)

		for plat in platforms:
			var type = _resolve_block_type(biome.palette, plat.role, _rng)
			_create_platform(Vector2(plat.x, y), plat.width, type)
			
		y -= _rng.randf_range(biome.gap_min, biome.gap_max)
	current_height = y

# ... [The rest of your utility functions: _get_biome_at, _pick_template, _create_platform, etc.] ...

func _get_biome_at(frac: float) -> Biome:
	for b in _biomes:
		if frac >= b.height_start and frac < b.height_end: return b
	return _biomes.back()

func _pick_template(biome: Biome, rng: RandomNumberGenerator) -> int:
	var total = 0
	for w in biome.tmpl_weights: total += w
	var roll = rng.randi_range(0, total - 1)
	var cum = 0
	for i in range(biome.tmpl_weights.size()):
		cum += biome.tmpl_weights[i]
		if roll < cum: return i
	return 0

func _build_template(tmpl: int, rng: RandomNumberGenerator, plat_min: float, plat_max: float) -> Array:
	var usable := float(map_width) - 250.0
	var half := usable * 0.5
	var results := []
	
	# Simple spacing logic from previous fix
	match tmpl:
		0: # OPEN
			var count = rng.randi_range(1, 2)
			for i in range(count):
				results.append({"x": rng.randf_range(-half, half), "width": rng.randf_range(plat_min, plat_max), "role": "standard"})
		1: # CORRIDOR
			var gap = 220.0
			var center = rng.randf_range(-100, 100)
			results.append({"x": center - 300, "width": 400, "role": "wall"})
			results.append({"x": center + 300, "width": 400, "role": "wall"})
		2: # STAIRS
			for i in range(3):
				results.append({"x": -half + (usable/3)*i, "width": plat_min, "role": "step"})
		3: # CHOKE
			results.append({"x": rng.randf_range(-50, 50), "width": plat_min, "role": "choke"})
		4: # SAFE
			results.append({"x": 0, "width": plat_max * 1.2, "role": "safe"})
	return results

func _create_platform(pos: Vector2, length: float, type: String) -> void:
	var scene = _get_block_scene(type)
	if not scene: return
	var block = scene.instantiate()
	block.global_position = pos
	if block.has_method("set_block_size"): 
		block.set_block_size(Vector2(length, 64))
	add_child(block)
	generated_blocks.append(block)

func _get_block_scene(type: String) -> PackedScene:
	match type:
		"destructible": return destructible_block_scene
		"bouncy": return bouncy_block_scene
		"ice": return ice_block_scene
		"reverse": return reverse_block_scene
		"moving": return moving_platform_scene
	return regular_block_scene

func cleanup_below(y_level: float) -> void:
	var to_remove = []
	for b in generated_blocks:
		if is_instance_valid(b) and b.global_position.y > y_level: to_remove.append(b)
	for b in to_remove:
		generated_blocks.erase(b)
		b.queue_free()

func get_height() -> float: return current_height
