extends Node2D

# ─────────────────────────────────────────────
#  GORGE BACKGROUND
#  Two-layer jagged mountain silhouette with
#  parallax, fog, and optional rock detail lines.
# ─────────────────────────────────────────────

@export_group("Visuals")
@export var back_mountain_color:  Color = Color("#0f121a")
@export var fore_mountain_color:  Color = Color("#161a24")
@export var fog_color:            Color = Color(0.165, 0.212, 0.290, 0.28)
@export var detail_line_color:    Color = Color(1.0, 1.0, 1.0, 0.03)
@export var show_detail_lines:    bool  = true

@export_group("Gorge Shape")
@export var base_width:           float = 1100.0
@export var noise_amplitude:      float = 180.0
@export var vertical_resolution:  float = 80.0
@export var y_top:                float = -15000.0
@export var y_bottom:             float =  1000.0
@export var center_clear:         float =  350.0   # half-width of guaranteed clear zone

@export_group("Parallax")
@export var back_parallax:        float = 0.06    # back layer vertical lag
@export var fore_parallax:        float = 0.10    # fore layer vertical lag

var _rng := RandomNumberGenerator.new()

# Pre-built polygon point arrays — generated once, drawn every frame
var _back_left:  PackedVector2Array
var _back_right: PackedVector2Array
var _fore_left:  PackedVector2Array
var _fore_right: PackedVector2Array

# Separate detail line arrays per layer
var _back_details: Array  = []   # Array of [Vector2, Vector2]
var _fore_details: Array  = []

var _cam_y: float = 0.0

# ─────────────────────────────────────────────
#  INIT
# ─────────────────────────────────────────────

func _ready() -> void:
	_rng.randomize()
	z_index = -20
	_generate_all()
	queue_redraw()

func _generate_all() -> void:
	_back_left  = _build_side(true,  1.2, 0.5, _back_details)
	_back_right = _build_side(false, 1.2, 0.5, _back_details)
	_fore_left  = _build_side(true,  1.0, 1.0, _fore_details)
	_fore_right = _build_side(false, 1.0, 1.0, _fore_details)

# ─────────────────────────────────────────────
#  GEOMETRY BUILDER
# ─────────────────────────────────────────────

func _build_side(
	is_left:    bool,
	width_mult: float,
	noise_mult: float,
	detail_list: Array
) -> PackedVector2Array:
	var points := PackedVector2Array()
	var far_x:  float = -3000.0 if is_left else 3000.0
	var y:      float = y_bottom

	points.append(Vector2(far_x, y))

	var prev_x: float = far_x

	while y > y_top:
		var wave:   float = sin(y * 0.005) * noise_amplitude * noise_mult
		var jitter: float = _rng.randf_range(-30.0, 30.0)
		var x_base: float = (-base_width * 0.5) if is_left else (base_width * 0.5)
		var x:      float = x_base * width_mult + wave + jitter

		x = min(x, -center_clear) if is_left else max(x, center_clear)

		points.append(Vector2(x, y))

		# Detail lines: occasional faint vertical crack segments on the rock face
		if show_detail_lines and _rng.randf() < 0.06:
			var crack_len: float = _rng.randf_range(40.0, 120.0)
			var cx: float = lerp(x, far_x, _rng.randf_range(0.1, 0.5))
			detail_list.append([
				Vector2(cx, y),
				Vector2(cx + _rng.randf_range(-8.0, 8.0), y - crack_len)
			])

		prev_x = x
		y -= vertical_resolution

	points.append(Vector2(far_x, y_top))
	points.append(Vector2(far_x, y_bottom))

	return points

# ─────────────────────────────────────────────
#  PARALLAX
# ─────────────────────────────────────────────

func _process(_delta: float) -> void:
	var cam := get_viewport().get_camera_2d()
	if not cam:
		return
	var new_y: float = cam.global_position.y
	if not is_equal_approx(new_y, _cam_y):
		_cam_y = new_y
		queue_redraw()

# ─────────────────────────────────────────────
#  DRAW
# ─────────────────────────────────────────────

func _draw() -> void:
	# Each layer is offset by a fraction of camera Y for parallax depth.
	# draw_set_transform shifts the coordinate system before each layer.

	# ── Back layer ───────────────────────────
	draw_set_transform(Vector2(0.0, _cam_y * back_parallax))
	draw_polygon(_back_left,  [back_mountain_color])
	draw_polygon(_back_right, [back_mountain_color])

	if show_detail_lines:
		for seg in _back_details:
			draw_line(seg[0], seg[1], detail_line_color, 1.0)

	# ── Atmospheric fog between layers ───────
	draw_set_transform(Vector2.ZERO)
	draw_rect(Rect2(-5000.0, y_top - 1000.0, 10000.0, abs(y_top) + y_bottom + 1000.0), fog_color)

	# ── Fore layer ───────────────────────────
	draw_set_transform(Vector2(0.0, _cam_y * fore_parallax))
	draw_polygon(_fore_left,  [fore_mountain_color])
	draw_polygon(_fore_right, [fore_mountain_color])

	if show_detail_lines:
		for seg in _fore_details:
			draw_line(seg[0], seg[1], detail_line_color, 1.0)

	# Reset transform
	draw_set_transform(Vector2.ZERO)
