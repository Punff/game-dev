extends Control

func _ready():
	create_menu_ui()

func create_menu_ui():
	var canvas = CanvasLayer.new()
	add_child(canvas)
	
	var vbox = VBoxContainer.new()
	vbox.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	vbox.add_theme_constant_override("separation", 20)
	canvas.add_child(vbox)
	
	var title = Label.new()
	title.text = "Up"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	
	var btn_1p = Button.new()
	btn_1p.text = "SINGLE PLAYER"
	btn_1p.pressed.connect(func(): start_game(1))
	vbox.add_child(btn_1p)
	
	var btn_2p = Button.new()
	btn_2p.text = "LOCAL MULTIPLAYER"
	btn_2p.pressed.connect(func(): start_game(2))
	vbox.add_child(btn_2p)

func start_game(players: int):
	var game_scene = load("res://game.tscn")
	var game_instance = game_scene.instantiate()
	
	# We store the player count inside the game instance itself
	game_instance.set_meta("player_count", players)
	
	get_tree().root.add_child(game_instance)
	get_tree().current_scene = game_instance
	self.queue_free()
