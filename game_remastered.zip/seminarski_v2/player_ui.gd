extends Node2D

# ─────────────────────────────────────────────
#  PLAYER UI  —  height + gravity cooldown ring
#  Follows player with a slight lag/wobble.
#  Draws a white arc ring showing gravity recharge.
# ─────────────────────────────────────────────

@export var player_id:    int   = 1
@export var side_offset:  float = 650.0
@export var label_color:  Color = Color(1.0, 1.0, 1.0, 0.9)
@export var follow_speed: float = 6.0    # lower = more lag, higher = tighter
@export var ring_radius:  float = 18.0

var _player:     Node    = null
var _label:      Label   = null
var _initial_y:  float   = 0.0
var _ref_set:    bool    = false
var _max_height: float   = 0.0
var _target:     Vector2 = Vector2.ZERO
var _cooldown:   float   = 1.0   # 0 = on cooldown, 1 = ready

func _ready() -> void:
	var nodes: Array = get_tree().get_nodes_in_group("player%d" % player_id)
	if not nodes.is_empty():
		_player = nodes[0]
		_target = _player.global_position

	_label = Label.new()
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.add_theme_font_size_override("font_size", 18)
	_label.add_theme_color_override("font_color",        label_color)
	_label.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.9))
	_label.add_theme_constant_override("shadow_offset_x", 2)
	_label.add_theme_constant_override("shadow_offset_y", 2)
	_label.position = Vector2(-30.0, -ring_radius - 26.0)
	add_child(_label)

func _process(delta: float) -> void:
	if not is_instance_valid(_player):
		return

	if not _ref_set:
		_initial_y = _player.global_position.y
		_ref_set   = true

	var height: float = (_initial_y - _player.global_position.y) / 100.0
	if height > _max_height:
		_max_height = height
	_label.text = "%dm" % int(_max_height)

	if _player.has_method("get_gravity_field_cooldown_progress"):
		_cooldown = _player.get_gravity_field_cooldown_progress()

	# Lag follow — target updates instantly, position lerps toward it
	var sign: float = -1.0 if player_id == 1 else 1.0
	_target         = _player.global_position + Vector2(sign * side_offset, -20.0)
	global_position = global_position.lerp(_target, follow_speed * delta)

	queue_redraw()

func _draw() -> void:
	# Dim background ring — always visible
	draw_arc(Vector2.ZERO, ring_radius, 0.0, TAU, 48,
		Color(1.0, 1.0, 1.0, 0.15), 2.5)

	if _cooldown < 1.0:
		# Fills clockwise from top as cooldown recovers
		var arc_end: float = -PI * 0.5 + TAU * _cooldown
		draw_arc(Vector2.ZERO, ring_radius, -PI * 0.5, arc_end, 48,
			Color(1.0, 1.0, 1.0, 0.55), 2.5)
	else:
		# Ready — full bright ring + dot at top
		draw_arc(Vector2.ZERO, ring_radius, 0.0, TAU, 48,
			Color(1.0, 1.0, 1.0, 0.88), 2.5)
		draw_circle(Vector2(0.0, -ring_radius), 3.0, Color(1.0, 1.0, 1.0, 0.9))

func reset() -> void:
	_max_height = 0.0
	_ref_set    = false

func _on_level_restart() -> void:
	reset()
