extends Node

# 1 = Singleplayer, 2 = Multiplayer
var target_player_count: int = 2
