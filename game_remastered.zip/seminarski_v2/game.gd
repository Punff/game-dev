extends Node2D

# ─────────────────────────────────────────────
#  GAME MANAGER
# ─────────────────────────────────────────────

# ── State ────────────────────────────────────
var player1:      CharacterBody2D
var player2:      CharacterBody2D
var game_active:  bool = true
var player_mode:  int  = 2   # 1 = singleplayer, 2 = multiplayer

# ── UI references ────────────────────────────
var game_end_screen: Control
var pause_screen:    Control

# ─────────────────────────────────────────────
#  INITIALISATION
# ─────────────────────────────────────────────

func _ready() -> void:
	_load_player_mode()
	await get_tree().process_frame
	await get_tree().physics_frame
	setup_game()
	_create_game_end_screen()
	_create_pause_screen()
	_setup_ui_layout()

func _load_player_mode() -> void:
	var root := get_tree().root
	if root.has_meta("saved_player_mode"):
		player_mode = root.get_meta("saved_player_mode")
		root.remove_meta("saved_player_mode")
	elif has_meta("player_count"):
		player_mode = get_meta("player_count")

# ─────────────────────────────────────────────
#  GAME SETUP
# ─────────────────────────────────────────────

func setup_game() -> void:
	player1 = get_node_or_null("Player1")
	player2 = get_node_or_null("Player2")

	if player1:
		var p1_start := Vector2(-200 if player_mode == 2 else 0, -200)
		_reset_player(player1, p1_start)
		_connect_death_signal(player1)

	if player2:
		if player_mode == 1:
			player2.queue_free()
			player2 = null
		else:
			_reset_player(player2, Vector2(200, -200))
			_connect_death_signal(player2)

func _reset_player(p: CharacterBody2D, pos: Vector2) -> void:
	if not is_instance_valid(p):
		return
	p.process_mode      = Node.PROCESS_MODE_INHERIT
	p.visible           = true
	p.is_dead           = false
	p.velocity          = Vector2.ZERO
	p.global_position   = pos
	p.set_collision_layer_value(1, true)
	p.set_collision_mask_value(1, true)
	p.set_physics_process(true)
	if p.has_method("reset_player"):
		p.reset_player()

func _connect_death_signal(p: CharacterBody2D) -> void:
	if not p.player_died.is_connected(_on_player_died):
		p.player_died.connect(_on_player_died)

# ─────────────────────────────────────────────
#  GAMEPLAY LOGIC
# ─────────────────────────────────────────────

func _on_player_died(player_id: int) -> void:
	if not game_active:
		return
	game_active = false
	get_tree().paused = true

	var winner_text := _get_winner_text(player_id)
	_show_game_end_screen(winner_text)

func _get_winner_text(loser_id: int) -> String:
	if player_mode == 1:
		return "YOU DIED"
	match loser_id:
		1: return "PLAYER 2 WINS"
		2: return "PLAYER 1 WINS"
	return "GAME OVER"

func _on_play_again_pressed() -> void:
	get_tree().paused = false
	get_tree().root.set_meta("saved_player_mode", player_mode)
	get_tree().reload_current_scene()

func _on_menu_pressed() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://main_menu.tscn")

# ─────────────────────────────────────────────
#  INPUT
# ─────────────────────────────────────────────

func _input(ev: InputEvent) -> void:
	if ev.is_action_pressed("ui_cancel"):
		toggle_pause()

func toggle_pause() -> void:
	if not is_instance_valid(game_end_screen) or game_end_screen.visible:
		return
	get_tree().paused = not get_tree().paused
	pause_screen.visible = get_tree().paused

	# Return focus to resume button when unpausing via keyboard
	if not get_tree().paused:
		var btn := pause_screen.find_child("ResumeBtn", true, false) as Button
		if btn:
			btn.release_focus()

# ─────────────────────────────────────────────
#  UI — GAME END SCREEN
# ─────────────────────────────────────────────

func _create_game_end_screen() -> void:
	var canvas := CanvasLayer.new()
	canvas.layer = 102
	add_child(canvas)

	game_end_screen = Control.new()
	game_end_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	game_end_screen.visible      = false
	game_end_screen.process_mode = Node.PROCESS_MODE_ALWAYS

	# Background
	var bg := ColorRect.new()
	bg.color = Color(0.08, 0.08, 0.08, 0.92)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	game_end_screen.add_child(bg)

	# Centred column
	var col := VBoxContainer.new()
	col.name = "Col"
	col.add_theme_constant_override("separation", 16)
	col.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	col.size = Vector2(300, 0)   # fixed width; height grows with content
	game_end_screen.add_child(col)

	# Title label — text filled in at show time
	var title := Label.new()
	title.name                  = "Title"
	title.horizontal_alignment  = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 36)
	col.add_child(title)

	# Spacer
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 12)
	col.add_child(spacer)

	# Play again
	var btn_again := Button.new()
	btn_again.name                = "Again"
	btn_again.text                = "PLAY AGAIN"
	btn_again.custom_minimum_size = Vector2(300, 60)
	btn_again.pressed.connect(_on_play_again_pressed)
	col.add_child(btn_again)

	# Back to menu
	var btn_menu := Button.new()
	btn_menu.text                = "BACK TO MENU"
	btn_menu.custom_minimum_size = Vector2(300, 60)
	btn_menu.pressed.connect(_on_menu_pressed)
	col.add_child(btn_menu)

	canvas.add_child(game_end_screen)

func _show_game_end_screen(result_text: String) -> void:
	var title := game_end_screen.find_child("Title", true, false) as Label
	if title:
		title.text = result_text

	game_end_screen.visible = true

	var btn := game_end_screen.find_child("Again", true, false) as Button
	if btn:
		btn.grab_focus()

# ─────────────────────────────────────────────
#  UI — PAUSE SCREEN
# ─────────────────────────────────────────────

func _create_pause_screen() -> void:
	var canvas := CanvasLayer.new()
	canvas.layer = 100
	add_child(canvas)

	pause_screen = Control.new()
	pause_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_screen.visible      = false
	pause_screen.process_mode = Node.PROCESS_MODE_ALWAYS

	# Background
	var bg := ColorRect.new()
	bg.color = Color(0.0, 0.0, 0.0, 0.55)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_screen.add_child(bg)

	# Centred column
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 16)
	col.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	col.size = Vector2(300, 0)
	pause_screen.add_child(col)

	# Title
	var title := Label.new()
	title.text                 = "PAUSED"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 36)
	col.add_child(title)

	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 12)
	col.add_child(spacer)

	# Resume
	var btn_resume := Button.new()
	btn_resume.name                = "ResumeBtn"
	btn_resume.text                = "RESUME"
	btn_resume.custom_minimum_size = Vector2(300, 60)
	btn_resume.pressed.connect(toggle_pause)
	col.add_child(btn_resume)

	# Menu
	var btn_menu := Button.new()
	btn_menu.text                = "BACK TO MENU"
	btn_menu.custom_minimum_size = Vector2(300, 60)
	btn_menu.pressed.connect(_on_menu_pressed)
	col.add_child(btn_menu)

	canvas.add_child(pause_screen)

# ─────────────────────────────────────────────
#  UI — HUD LAYOUT
# ─────────────────────────────────────────────

func _setup_ui_layout() -> void:
	var ui_p1 := get_node_or_null("Player1UI")
	var ui_p2 := get_node_or_null("Player2UI")

	if ui_p1:
		ui_p1.position = Vector2(20, 20)

	if ui_p2:
		ui_p2.visible  = (player_mode == 2)
		# Deferred so viewport size is settled
		ui_p2.set_deferred("position",
			Vector2(get_viewport().get_visible_rect().size.x - 220, 20))
