extends Node2D

@export var titan_color: Color = Color(0.1, 0.12, 0.18, 0.7)
@export var titan_count: int = 6

var titans = []

func _ready():
	# We use a hardcoded seed so they stay in one place
	seed(1337)
	titans.clear()
	
	for i in range(titan_count):
		var h = randf_range(1800, 3000)
		var w = h * 0.2
		# Spawn them in a huge block around the origin
		var spawn_pos = Vector2(randf_range(-1500, 1500), randf_range(-2000, 2000))
		
		var points = PackedVector2Array([
			Vector2(-w/3, 0),
			Vector2(-w/2, -h * 0.4),
			Vector2(-w/6, -h), # Thinner top for less "blobby" look
			Vector2(w/6, -h),
			Vector2(w/2, -h * 0.4),
			Vector2(w/3, 0)
		])
		
		titans.append({"pos": spawn_pos, "points": points, "phase": randf() * PI})

func _process(_delta):
	queue_redraw()

func _draw():
	var time = Time.get_ticks_msec() / 1000.0
	for t in titans:
		# Extremely slow breathing sway
		var sway = sin(time * 0.05 + t.phase) * 30.0
		var current_pos = t.pos + Vector2(sway, 0)
		
		var draw_pts = []
		for p in t.points:
			draw_pts.append(p + current_pos)
			
		draw_colored_polygon(draw_pts, titan_color)
		# Draw a thin, bright "rim light" on one side to break the blob
		var rim_pts = PackedVector2Array([draw_pts[1], draw_pts[2], draw_pts[3]])
		draw_polyline(rim_pts, titan_color.lightened(0.3), 1.5)
