extends Node2D

@export var block_size: Vector2 = Vector2(64, 64)
@export var block_color: Color = Color(0.2, 0.8, 0.4)
@export var bounce_force: float = 800.0

var bounce_tween: Tween

func _ready():
	add_to_group("bouncy_blocks")
	create_block()

func create_block():
	var block = StaticBody2D.new()
	block.name = "Block"
	
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = block_size
	collision.shape = shape
	block.add_child(collision)
	
	# 1. THE BASE
	var base_rect = ColorRect.new()
	base_rect.size = block_size
	base_rect.position = -block_size / 2 + Vector2(0, 4)
	base_rect.color = block_color.darkened(0.5)
	block.add_child(base_rect)
	
	# 2. THE VISUAL (Existing variable)
	var visual = ColorRect.new()
	visual.name = "Visual"
	visual.size = block_size
	visual.position = -block_size / 2
	visual.color = block_color
	block.add_child(visual)
	
	# 3. SUBTLE PATTERN (Adds a bit of visual interest)
	var stripe = ColorRect.new()
	stripe.size = Vector2(block_size.x, 4)
	stripe.position = Vector2(0, -2)
	stripe.color = Color(1, 1, 1, 0.2) # White tint stripe
	visual.add_child(stripe)

	var area = Area2D.new()
	area.name = "LandingDetector"
	
	var area_collision = CollisionShape2D.new()
	var area_shape = RectangleShape2D.new()
	area_shape.size = block_size + Vector2(10, 20)
	area_collision.shape = area_shape
	area_collision.position = Vector2(0, -5)
	area.add_child(area_collision)
	
	area.body_entered.connect(_on_player_landed)
	
	add_child(area)
	add_child(block)

func _on_player_landed(body):
	if body is CharacterBody2D:
		var should_bounce = false
		
		if body.velocity.y > 50:
			should_bounce = true
		elif body.is_on_floor() and abs(body.velocity.y) < 100:
			should_bounce = true
		
		if should_bounce:
			bounce_player(body)
			play_bounce_animation()

func receive_force(force_origin, force_strength):
	pass

func bounce_player(player):
	if player is CharacterBody2D:
		player.velocity.y = -bounce_force

func play_bounce_animation():
	if bounce_tween:
		bounce_tween.kill()
	
	bounce_tween = create_tween()
	bounce_tween.set_loops(1)
	
	bounce_tween.tween_property(self, "scale", Vector2(1.1, 0.8), 0.1)
	bounce_tween.tween_property(self, "scale", Vector2.ONE, 0.2)
