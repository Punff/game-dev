extends Node2D

@export var block_size: Vector2 = Vector2(256, 64): set = set_block_size
@export var block_color: Color = Color(0.4, 0.4, 0.4): set = set_block_color
@export var edge_color: Color = Color(0.6, 0.6, 0.6): set = set_edge_color

var block_active = true

func _ready():
	add_to_group("regular_blocks")
	var block = create_block()
	add_child(block)

func set_block_size(new_size: Vector2):
	block_size = new_size
	update_block_visuals()

func set_block_color(new_color: Color):
	block_color = new_color
	update_block_visuals()

func set_edge_color(new_color: Color):
	edge_color = new_color
	update_block_visuals()

func update_block_visuals():
	if not is_inside_tree():
		return
		
	var block = get_node_or_null("Block")
	if not block:
		return
	
	# Update collision shape
	var collision = block.get_node_or_null("CollisionShape2D")
	if collision and collision.shape is RectangleShape2D:
		collision.shape.size = block_size
	
	# Update visual
	var visual = block.get_node_or_null("ColorRect")
	if visual:
		visual.size = block_size
		visual.position = -block_size / 2
		visual.color = block_color
	
	# Update border
	var border = block.get_node_or_null("Line2D")
	if border:
		border.clear_points()
		border.add_point(Vector2(-block_size.x/2, -block_size.y/2))
		border.add_point(Vector2(block_size.x/2, -block_size.y/2))
		border.add_point(Vector2(block_size.x/2, block_size.y/2))
		border.add_point(Vector2(-block_size.x/2, block_size.y/2))
		border.add_point(Vector2(-block_size.x/2, -block_size.y/2))
		border.default_color = edge_color

func create_block():
	var block = StaticBody2D.new()
	block.name = "Block"
	
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = block_size
	collision.shape = shape
	block.add_child(collision)
	
	# 1. THE SIDE/SHADOW (New unique variable name)
	var shadow_rect = ColorRect.new()
	shadow_rect.size = block_size
	# Offset it down by 6 pixels to give it "thickness"
	shadow_rect.position = -block_size / 2 + Vector2(0, 6)
	shadow_rect.color = block_color.darkened(0.4) # Darker version
	block.add_child(shadow_rect)
	
	# 2. THE TOP SURFACE (Original variable name)
	var visual = ColorRect.new()
	visual.name = "ColorRect"
	visual.size = block_size
	visual.position = -block_size / 2
	visual.color = block_color
	block.add_child(visual)
	
	# 3. CLEAN BORDER
	var border = Line2D.new()
	border.name = "Line2D"
	border.points = [
		Vector2(-block_size.x/2, -block_size.y/2),
		Vector2(block_size.x/2, -block_size.y/2),
		Vector2(block_size.x/2, block_size.y/2),
		Vector2(-block_size.x/2, block_size.y/2),
		Vector2(-block_size.x/2, -block_size.y/2)
	]
	border.width = 2.0
	border.default_color = edge_color
	block.add_child(border)
	
	return block

func receive_force(force_origin, force_strength):
	# Regular blocks don't break, but we can add visual feedback
	if force_strength >= 50.0:
		play_impact_animation()

func play_impact_animation():
	var block = $Block
	if not block:
		return
		
	var tween = create_tween()
	tween.set_parallel(true)
	
	# Small shake effect
	tween.tween_property(block, "position", Vector2(2, 0), 0.05)
	tween.tween_property(block, "position", Vector2(-2, 0), 0.05).set_delay(0.05)
	tween.tween_property(block, "position", Vector2.ZERO, 0.05).set_delay(0.1)
	
	# Brief color flash
	var visual = block.get_node("ColorRect")
	if visual:
		tween.tween_property(visual, "color", block_color.lightened(0.3), 0.1)
		tween.tween_property(visual, "color", block_color, 0.1).set_delay(0.1)

func _property_list_changed():
	if Engine.is_editor_hint():
		for child in get_children():
			child.queue_free()
		
		var block = create_block()
		add_child(block)
