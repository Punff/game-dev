extends Node2D

@export_range(0.0001, 0.01) var fragment_density: float = 0.001
@export_range(4, 16) var min_fragments: int = 6
@export_range(16, 100) var max_fragments: int = 50
@export var block_color: Color = Color(0.8, 0.4, 0.2)
@export var edge_color: Color = Color(0.6, 0.3, 0.15)
@export var gravity_scale: float = 0.01
@export var break_threshold: float = 100.0
@export var destruction_timeout: float = 60.0
@export var fragment_collision_layer: int = 1
@export var block_size: Vector2 = Vector2(128, 64)

var _rng = RandomNumberGenerator.new()
var fragments = []
var regions = []
var block_active = true
var fragment_count = 16
var broken_region_ids = []

func _ready():
	_rng.randomize()
	add_to_group("destructible_blocks")
	calculate_fragment_count()
	var block = create_block()
	add_child(block)
	generate_voronoi_regions()

func calculate_fragment_count():
	var area = block_size.x * block_size.y
	var calculated_fragments = int(area * fragment_density)
	fragment_count = clamp(calculated_fragments, min_fragments, max_fragments)

func create_block():
	var block = StaticBody2D.new()
	block.name = "Block"
	
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = block_size
	collision.shape = shape
	block.add_child(collision)
	
	# Depth Ledge (Shadow)
	var shadow_rect = ColorRect.new()
	shadow_rect.size = block_size
	shadow_rect.position = -block_size / 2 + Vector2(0, 6)
	shadow_rect.color = block_color.darkened(0.4)
	block.add_child(shadow_rect)
	
	# Main Surface
	var visual = ColorRect.new()
	visual.name = "Visual"
	visual.size = block_size
	visual.position = -block_size / 2
	visual.color = block_color
	block.add_child(visual)
	
	return block

func generate_voronoi_regions():
	var points = []
	var columns = ceil(sqrt(fragment_count * block_size.x / block_size.y))
	var rows = ceil(fragment_count / float(columns))
	var cell_width = block_size.x / columns
	var cell_height = block_size.y / rows
	
	for i in range(rows):
		for j in range(columns):
			if points.size() >= fragment_count:
				break
				
			var point = Vector2(
				-block_size.x/2 + j * cell_width + _rng.randf() * cell_width,
				-block_size.y/2 + i * cell_height + _rng.randf() * cell_height
			)
			points.append(point)
	
	calculate_regions(points)

func calculate_regions(points):
	for i in range(points.size()):
		var region = []
		var center = points[i]
		
		var area = block_size.x * block_size.y
		var avg_fragment_area = area / fragment_count
		var approximate_radius = sqrt(avg_fragment_area / PI) * 1.5
		
		var num_vertices = _rng.randi_range(5, 8)
		for j in range(num_vertices):
			var angle = TAU * j / num_vertices
			var radius_variation = _rng.randf_range(0.8, 1.2)
			var point = center + Vector2(cos(angle), sin(angle)) * approximate_radius * radius_variation
			
			point.x = clamp(point.x, -block_size.x/2, block_size.x/2)
			point.y = clamp(point.y, -block_size.y/2, block_size.y/2)
			
			region.append(point)
		
		region.sort_custom(func(a, b): 
			return atan2(a.y - center.y, a.x - center.x) < atan2(b.y - center.y, b.x - center.x)
		)
		
		if region.size() >= 3:
			regions.append({
				"points": region,
				"center": center,
				"id": i
			})

func receive_force(force_origin, force_strength):
	if regions.is_empty() and fragments.is_empty():
		return
		
	if force_strength >= break_threshold:
		break_apart_at_location(force_origin, force_strength)
	
	apply_force_to_fragments(force_origin, force_strength)

func break_apart_at_location(force_origin, force_strength):
	var unbroken_regions = []
	for region in regions:
		if not region.id in broken_region_ids:
			unbroken_regions.append(region)
	
	if unbroken_regions.is_empty():
		return
		
	var affected_regions = []
	var remaining_regions = []
	var force_radius = 100.0
	
	for node in get_tree().get_nodes_in_group("player"):
		if node.has_method("get_jump_force_radius"):
			force_radius = node.get_jump_force_radius()
		break
	
	var local_force_origin = to_local(force_origin)
	
	var effective_radius = force_radius
	if unbroken_regions.size() <= 5:
		effective_radius = force_radius * 1.5
	
	for region in unbroken_regions:
		var distance = region.center.distance_to(local_force_origin)
		if distance <= effective_radius:
			affected_regions.append(region)
		else:
			remaining_regions.append(region)
	
	if affected_regions.size() == 0:
		var closest_region = null
		var closest_distance = INF
		for region in unbroken_regions:
			var distance = region.center.distance_to(local_force_origin)
			if distance < closest_distance:
				closest_distance = distance
				closest_region = region
		if closest_region:
			affected_regions.append(closest_region)
			remaining_regions.erase(closest_region)
	
	if affected_regions.size() == 0:
		return
	
	if block_active:
		var original_block = get_node_or_null("Block")
		if original_block:
			original_block.queue_free()
			block_active = false
	else:
		var remaining_block = get_node_or_null("RemainingBlock")
		if remaining_block:
			remaining_block.queue_free()
	
	if remaining_regions.size() > 0:
		create_remaining_block(remaining_regions)
	
	for region in affected_regions:
		create_fragment(region.points, force_origin, force_strength)
		broken_region_ids.append(region.id)

func apply_force_to_fragments(force_origin, force_strength):
	fragments = fragments.filter(func(fragment): return is_instance_valid(fragment))
	for fragment in fragments:
		var direction = (fragment.global_position - force_origin).normalized()
		var distance = fragment.global_position.distance_to(force_origin)
		if distance <= 100.0:
			var force_factor = 1.0 - clamp(distance / 100.0, 0.0, 1.0)
			fragment.apply_central_impulse(direction * force_strength * force_factor * 0.5)

func create_remaining_block(remaining_regions):
	var static_block = StaticBody2D.new()
	static_block.name = "RemainingBlock"
	
	for region in remaining_regions:
		var shadow = Polygon2D.new()
		shadow.polygon = region.points
		shadow.position = Vector2(0, 6)
		shadow.color = block_color.darkened(0.4)
		static_block.add_child(shadow)
		
		var visual = Polygon2D.new()
		visual.polygon = region.points
		visual.color = block_color
		static_block.add_child(visual)
		
		var shape = CollisionPolygon2D.new()
		shape.polygon = region.points
		# UPDATED LINE BELOW
		shape.build_mode = CollisionPolygon2D.BUILD_SOLIDS 
		static_block.add_child(shape)
		
		var line = Line2D.new()
		line.points = region.points + [region.points[0]]
		line.width = 1.5
		line.default_color = edge_color
		static_block.add_child(line)
	
	add_child(static_block)

func create_fragment(points, force_origin, force_strength):
	var fragment = RigidBody2D.new()
	# Basic physics and grouping setup
	fragment.gravity_scale = gravity_scale
	fragment.collision_layer = fragment_collision_layer
	fragment.add_to_group("fragments")
	fragment.linear_damp = 1.0 
	fragment.angular_damp = 1.5 # Higher damping for more controlled spinning

	# 1. THE DEPTH LEDGE (Bottom Layer)
	# Offsetting a darker color creates that "clean" 3D look
	var shadow = Polygon2D.new()
	shadow.polygon = points
	shadow.position = Vector2(0, 3) 
	shadow.color = block_color.darkened(0.5)
	fragment.add_child(shadow)

	# 2. THE MAIN FACE (With color variance)
	var polygon = Polygon2D.new()
	polygon.polygon = points
	# Slight random tint so they don't look identical 
	var tint = randf_range(0.85, 1.1)
	polygon.color = block_color * Color(tint, tint, tint)
	polygon.name = "Polygon2D"
	fragment.add_child(polygon)

	# 3. THE FACETED HIGHLIGHT (The "Cool" Factor)
	var highlight = Polygon2D.new()
	var shrunk_points = []
	for p in points:
		shrunk_points.append(p * 0.75) 
	highlight.polygon = shrunk_points
	highlight.color = Color(1, 1, 1, 0.15) # Subtle shine overlay [cite: 6]
	fragment.add_child(highlight)

	# 4. CRISP OUTLINE
	var line = Line2D.new()
	line.points = points + [points[0]]
	line.width = 1.2
	line.default_color = edge_color
	line.antialiased = true
	fragment.add_child(line)

	# 5. COLLISION
	var collision = CollisionPolygon2D.new()
	collision.polygon = points
	fragment.add_child(collision)

	# Physics launch logic [cite: 6]
	var fragment_world_position = global_position + get_polygon_center(points)
	get_tree().current_scene.add_child(fragment)
	fragment.global_position = fragment_world_position
	
	var direction = (fragment_world_position - force_origin).normalized()
	fragment.apply_central_impulse(direction * randf_range(0.15, 0.35) * force_strength)
	fragment.angular_velocity = randf_range(-8.0, 8.0)
	
func fade_out_fragment(fragment):
	if not is_instance_valid(fragment): return
	var tween = create_tween()
	var poly = fragment.get_node_or_null("Polygon2D")
	if poly: tween.tween_property(poly, "modulate:a", 0.0, 1.0)
	await tween.finished
	fragments.erase(fragment)
	if is_instance_valid(fragment): fragment.queue_free()

func get_polygon_center(points):
	var sum = Vector2.ZERO
	for point in points: sum += point
	return sum / points.size()
