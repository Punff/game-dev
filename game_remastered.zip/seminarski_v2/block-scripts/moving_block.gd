extends Node2D

@export var block_size: Vector2 = Vector2(128, 32)
@export var block_color: Color = Color(0.7, 0.3, 0.8)
@export var edge_color: Color = Color(0.5, 0.2, 0.6)

@export var move_distance: float = 500.0
@export var move_speed: float = 150.0
@export var move_direction: Vector2 = Vector2(1, 0)

@export var enable_tilt: bool = true
@export var max_tilt_angle: float = 15.0
@export var tilt_smoothing: float = 2.0

@export var pause_at_ends: float = 0.5
@export var ease_type: Tween.EaseType = Tween.EASE_IN_OUT
@export var transition_type: Tween.TransitionType = Tween.TRANS_SINE

var start_position: Vector2
var end_position: Vector2
var moving_to_end: bool = true
var platform_body: CharacterBody2D
var is_paused: bool = false

func _ready():
	add_to_group("moving_blocks")
	setup_positions()
	create_platform()
	start_movement()

func setup_positions():
	start_position = global_position
	end_position = start_position + (move_direction.normalized() * move_distance)

func create_platform():
	platform_body = CharacterBody2D.new()
	platform_body.name = "Platform"
	
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = block_size
	collision.shape = shape
	platform_body.add_child(collision)
	
	# 1. THE THICKNESS (Shadow)
	var shadow_rect = ColorRect.new()
	shadow_rect.size = block_size
	shadow_rect.position = -block_size / 2 + Vector2(0, 6)
	shadow_rect.color = block_color.darkened(0.4)
	platform_body.add_child(shadow_rect)
	
	# 2. THE MAIN SURFACE
	var visual = ColorRect.new()
	visual.name = "Visual"
	visual.size = block_size
	visual.position = -block_size / 2
	visual.color = block_color
	platform_body.add_child(visual)
	
	# 3. BORDER
	var border = Line2D.new()
	border.points = [
		Vector2(-block_size.x/2, -block_size.y/2),
		Vector2(block_size.x/2, -block_size.y/2),
		Vector2(block_size.x/2, block_size.y/2),
		Vector2(-block_size.x/2, block_size.y/2),
		Vector2(-block_size.x/2, -block_size.y/2)
	]
	border.width = 2.0
	border.default_color = edge_color
	platform_body.add_child(border)
	
	add_child(platform_body)

func create_direction_indicators():
	var arrow_length = 8.0
	var arrow_offset = block_size.x / 3
	
	var left_arrow = Line2D.new()
	left_arrow.add_point(Vector2(-arrow_offset, 0))
	left_arrow.add_point(Vector2(-arrow_offset - arrow_length, -4))
	left_arrow.add_point(Vector2(-arrow_offset - arrow_length + 3, 0))
	left_arrow.add_point(Vector2(-arrow_offset - arrow_length, 4))
	left_arrow.add_point(Vector2(-arrow_offset, 0))
	left_arrow.width = 1.5
	left_arrow.default_color = Color.WHITE
	platform_body.add_child(left_arrow)
	
	var right_arrow = Line2D.new()
	right_arrow.add_point(Vector2(arrow_offset, 0))
	right_arrow.add_point(Vector2(arrow_offset + arrow_length, -4))
	right_arrow.add_point(Vector2(arrow_offset + arrow_length - 3, 0))
	right_arrow.add_point(Vector2(arrow_offset + arrow_length, 4))
	right_arrow.add_point(Vector2(arrow_offset, 0))
	right_arrow.width = 1.5
	right_arrow.default_color = Color.WHITE
	platform_body.add_child(right_arrow)

func start_movement():
	move_to_target()

func move_to_target():
	if is_paused:
		return
	
	var target = end_position if moving_to_end else start_position
	var current_pos = global_position
	var distance = current_pos.distance_to(target)
	var duration = distance / move_speed
	
	var move_tween = create_tween()
	move_tween.set_parallel(true)
	
	move_tween.tween_property(self, "global_position", target, duration)
	move_tween.tween_method(update_platform_physics, current_pos, target, duration)
	
	if enable_tilt:
		var tilt_direction = 1 if moving_to_end else -1
		var movement_dir = move_direction.normalized()
		
		var target_rotation = 0.0
		if movement_dir.x != 0:
			target_rotation = deg_to_rad(max_tilt_angle * tilt_direction * movement_dir.x)
		
		move_tween.tween_property(platform_body, "rotation", target_rotation, duration * 0.3)
	
	await move_tween.finished
	
	if pause_at_ends > 0:
		is_paused = true
		await get_tree().create_timer(pause_at_ends).timeout
		is_paused = false
	
	if enable_tilt:
		var level_tween = create_tween()
		level_tween.tween_property(platform_body, "rotation", 0.0, 0.2)
		await level_tween.finished
	
	moving_to_end = !moving_to_end
	move_to_target()

func update_platform_physics(current_position: Vector2):
	if platform_body:
		platform_body.global_position = current_position

func stop_platform():
	var tweens = get_tree().get_nodes_in_group("Tween")
	for tween in tweens:
		if tween.get_parent() == self:
			tween.kill()

func resume_platform():
	if not is_paused:
		move_to_target()

func reverse_direction():
	moving_to_end = !moving_to_end
	stop_platform()
	move_to_target()

func get_platform_velocity() -> Vector2:
	var direction = (end_position - start_position).normalized()
	if not moving_to_end:
		direction = -direction
	return direction * move_speed

func is_moving() -> bool:
	return !is_paused

func _physics_process(_delta):
	pass

func _draw():
	if Engine.is_editor_hint():
		draw_line(to_local(start_position), to_local(end_position), Color.YELLOW, 2.0)
		draw_circle(to_local(start_position), 5, Color.GREEN)
		draw_circle(to_local(end_position), 5, Color.RED)
