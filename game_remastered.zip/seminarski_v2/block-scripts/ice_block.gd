extends Node2D

@export var block_size: Vector2 = Vector2(64, 64)
@export var block_color: Color = Color(0.7, 0.9, 1.0)
@export var edge_color: Color = Color(0.5, 0.7, 0.9)
@export var ice_friction: float = 0.2
@export var ice_acceleration: float = 5.0
@export var effect_duration: float = 1.0
@export var effect_radius: float = 30.0

var affected_players: Array = []
var ice_tween: Tween

func _ready():
	add_to_group("ice_blocks")
	add_to_group("destructible_blocks")
	create_block()

func create_block():
	var block = StaticBody2D.new()
	block.name = "Block"
	
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = block_size
	collision.shape = shape
	block.add_child(collision)
	
	# 1. THE ICE THICKNESS
	var ice_depth = ColorRect.new()
	ice_depth.size = block_size
	ice_depth.position = -block_size / 2 + Vector2(0, 5)
	ice_depth.color = block_color.darkened(0.3)
	block.add_child(ice_depth)
	
	# 2. THE MAIN SURFACE
	var visual = ColorRect.new()
	visual.name = "Visual"
	visual.size = block_size
	visual.position = -block_size / 2
	visual.color = block_color
	# Make it slightly semi-transparent for an "icy" feel
	visual.color.a = 0.8
	block.add_child(visual)
	
	# 3. BORDER
	var border = Line2D.new()
	border.points = [
		Vector2(-block_size.x/2, -block_size.y/2),
		Vector2(block_size.x/2, -block_size.y/2),
		Vector2(block_size.x/2, block_size.y/2),
		Vector2(-block_size.x/2, block_size.y/2),
		Vector2(-block_size.x/2, -block_size.y/2)
	]
	border.width = 2.0
	border.default_color = edge_color
	block.add_child(border)
	
	return block

func create_ice_decorations():
	var block = get_node("Block")
	
	var crystal_size = 8.0
	var positions = [
		Vector2(-block_size.x/4, -block_size.y/4),
		Vector2(block_size.x/4, -block_size.y/4),
		Vector2(-block_size.x/4, block_size.y/4),
		Vector2(block_size.x/4, block_size.y/4),
		Vector2(0, 0)
	]
	
	for i in range(positions.size()):
		var crystal = Line2D.new()
		var pos = positions[i]
		
		crystal.add_point(pos + Vector2(-crystal_size, 0))
		crystal.add_point(pos + Vector2(crystal_size, 0))
		crystal.add_point(pos)
		crystal.add_point(pos + Vector2(0, -crystal_size))
		crystal.add_point(pos + Vector2(0, crystal_size))
		crystal.add_point(pos)
		crystal.add_point(pos + Vector2(-crystal_size*0.7, -crystal_size*0.7))
		crystal.add_point(pos + Vector2(crystal_size*0.7, crystal_size*0.7))
		crystal.add_point(pos)
		crystal.add_point(pos + Vector2(crystal_size*0.7, -crystal_size*0.7))
		crystal.add_point(pos + Vector2(-crystal_size*0.7, crystal_size*0.7))
		
		crystal.width = 1.0
		crystal.default_color = Color.WHITE
		block.add_child(crystal)

func _on_player_entered(body):
	if body is CharacterBody2D and not body in affected_players:
		affected_players.append(body)
		apply_ice_effect(body)
		start_ice_visual_effect()

func _on_player_exited(body):
	if body is CharacterBody2D and body in affected_players:
		start_ice_timer(body)

func apply_ice_effect(player):
	if not player.has_meta("original_friction"):
		if "friction" in player and "acceleration" in player:
			player.set_meta("original_friction", player.friction)
			player.set_meta("original_acceleration", player.acceleration)
			
			player.friction = ice_friction
			player.acceleration = ice_acceleration
			player.set_meta("on_ice", true)

func start_ice_timer(player):
	var timer = Timer.new()
	timer.wait_time = effect_duration
	timer.one_shot = true
	timer.autostart = true
	add_child(timer)
	
	timer.timeout.connect(func():
		remove_ice_effect(player)
		timer.queue_free()
	)

func remove_ice_effect(player):
	if is_instance_valid(player) and player.has_meta("original_friction"):
		if "friction" in player and "acceleration" in player:
			player.friction = player.get_meta("original_friction")
			player.acceleration = player.get_meta("original_acceleration")
		
		player.remove_meta("original_friction")
		player.remove_meta("original_acceleration") 
		player.remove_meta("on_ice")
		
		affected_players.erase(player)

func start_ice_visual_effect():
	if ice_tween:
		ice_tween.kill()
	
	ice_tween = create_tween()
	ice_tween.set_loops()
	
	var visual = $Block/Visual
	ice_tween.tween_property(visual, "color", block_color.lightened(0.2), 1.0)
	ice_tween.tween_property(visual, "color", block_color, 1.0)

func receive_force(_force_origin, _force_strength):
	var players = get_tree().get_nodes_in_group("player")
	for player in players:
		var distance = player.global_position.distance_to(_force_origin)
		if distance <= effect_radius and not player in affected_players:
			affected_players.append(player)
			apply_ice_effect(player)
			start_ice_timer(player)
			start_ice_visual_effect()

func is_player_on_ice(player) -> bool:
	return player.has_meta("on_ice")

func get_ice_effect_strength() -> float:
	return ice_friction

func force_remove_all_effects():
	for player in affected_players.duplicate():
		remove_ice_effect(player)

func _draw():
	if Engine.is_editor_hint():
		draw_circle(Vector2.ZERO, effect_radius, Color(0, 0.5, 1, 0.1))
		draw_arc(Vector2.ZERO, effect_radius, 0, TAU, 32, Color(0, 0.5, 1), 2)
