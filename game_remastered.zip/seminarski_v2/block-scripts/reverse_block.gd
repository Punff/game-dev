extends Node2D

@export var block_size: Vector2 = Vector2(64, 64)
@export var block_color: Color = Color(0.8, 0.2, 0.2)
@export var edge_color: Color = Color(0.6, 0.1, 0.1)
@export var reverse_duration: float = 3.0
@export var effect_radius: float = 80.0

var is_active: bool = false
var affected_players: Array = []
var visual_tween: Tween

func _ready():
	add_to_group("reverse_blocks")
	create_block()

func create_block():
	var block = StaticBody2D.new()
	block.name = "Block"
	
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = block_size
	collision.shape = shape
	block.add_child(collision)
	
	var visual = ColorRect.new()
	visual.name = "Visual"
	visual.size = block_size
	visual.position = -block_size / 2
	visual.color = block_color
	block.add_child(visual)
	
	var border = Line2D.new()
	border.add_point(Vector2(-block_size.x/2, -block_size.y/2))
	border.add_point(Vector2(block_size.x/2, -block_size.y/2))
	border.add_point(Vector2(block_size.x/2, block_size.y/2))
	border.add_point(Vector2(-block_size.x/2, block_size.y/2))
	border.add_point(Vector2(-block_size.x/2, -block_size.y/2))
	border.width = 2.0
	border.default_color = edge_color
	block.add_child(border)
	
	add_child(block)
	
	create_reverse_indicators()
	
	var area = Area2D.new()
	area.name = "DetectionArea"
	
	var area_collision = CollisionShape2D.new()
	var area_shape = CircleShape2D.new()
	area_shape.radius = effect_radius
	area_collision.shape = area_shape
	area.add_child(area_collision)
	
	area.body_entered.connect(_on_player_entered)
	area.body_exited.connect(_on_player_exited)
	
	add_child(area)

func create_reverse_indicators():
	var arrow_size = 12.0
	var arrow_spacing = 16.0
	
	var left_arrow = Line2D.new()
	left_arrow.add_point(Vector2(-arrow_spacing, -6))
	left_arrow.add_point(Vector2(-arrow_spacing + arrow_size, -6))
	left_arrow.add_point(Vector2(-arrow_spacing + arrow_size - 4, -10))
	left_arrow.add_point(Vector2(-arrow_spacing + arrow_size, -6))
	left_arrow.add_point(Vector2(-arrow_spacing + arrow_size - 4, -2))
	left_arrow.width = 2.0
	left_arrow.default_color = Color.WHITE
	
	var right_arrow = Line2D.new()
	right_arrow.add_point(Vector2(arrow_spacing, 6))
	right_arrow.add_point(Vector2(arrow_spacing - arrow_size, 6))
	right_arrow.add_point(Vector2(arrow_spacing - arrow_size + 4, 2))
	right_arrow.add_point(Vector2(arrow_spacing - arrow_size, 6))
	right_arrow.add_point(Vector2(arrow_spacing - arrow_size + 4, 10))
	right_arrow.width = 2.0
	right_arrow.default_color = Color.WHITE
	
	var x_symbol = Line2D.new()
	x_symbol.add_point(Vector2(-4, -4))
	x_symbol.add_point(Vector2(4, 4))
	x_symbol.add_point(Vector2(0, 0))
	x_symbol.add_point(Vector2(-4, 4))
	x_symbol.add_point(Vector2(4, -4))
	x_symbol.width = 2.0
	x_symbol.default_color = Color.YELLOW
	
	var block = get_node("Block")
	block.add_child(left_arrow)
	block.add_child(right_arrow)
	block.add_child(x_symbol)

func _on_player_entered(body):
	if body is CharacterBody2D and not body in affected_players:
		affected_players.append(body)
		apply_reverse_effect(body)
		activate_visual_effect()

func _on_player_exited(body):
	if body is CharacterBody2D and body in affected_players:
		start_reverse_timer(body)

func apply_reverse_effect(player):
	if not player.has_meta("controls_reversed"):
		player.set_meta("controls_reversed", true)
		player.set_meta("reverse_source", self)

func start_reverse_timer(player):
	var timer = Timer.new()
	timer.wait_time = reverse_duration
	timer.one_shot = true
	timer.autostart = true
	add_child(timer)
	
	timer.timeout.connect(func(): 
		remove_reverse_effect(player)
		timer.queue_free()
	)

func remove_reverse_effect(player):
	if is_instance_valid(player):
		player.remove_meta("controls_reversed")
		player.remove_meta("reverse_source")
		affected_players.erase(player)

func activate_visual_effect():
	if not is_active:
		is_active = true
		
		if visual_tween:
			visual_tween.kill()
		
		visual_tween = create_tween()
		visual_tween.set_loops()
		
		var visual = $Block/Visual
		visual_tween.tween_property(visual, "color", block_color.lightened(0.3), 0.5)
		visual_tween.tween_property(visual, "color", block_color, 0.5)

func receive_force(_force_origin, _force_strength):
	var players = get_tree().get_nodes_in_group("player")
	for player in players:
		var distance = player.global_position.distance_to(_force_origin)
		if distance <= effect_radius and not player in affected_players:
			affected_players.append(player)
			apply_reverse_effect(player)
			start_reverse_timer(player)
			activate_visual_effect()

func is_player_affected(player) -> bool:
	return player in affected_players

func get_reverse_duration() -> float:
	return reverse_duration

func force_remove_all_effects():
	for player in affected_players.duplicate():
		remove_reverse_effect(player)

func _draw():
	if Engine.is_editor_hint():
		draw_circle(Vector2.ZERO, effect_radius, Color(1, 0, 0, 0.1))
		draw_arc(Vector2.ZERO, effect_radius, 0, TAU, 32, Color.RED, 2)
