
extends Node2D

var radius = 10.0
var max_radius = 100.0
var speed = 200.0
var color = Color(0.2, 0.5, 1.0, 0.5)

func _process(delta):
	radius += speed * delta
	queue_redraw()
	
	if radius >= max_radius:
		queue_free()

func _draw():
	draw_circle(Vector2.ZERO, radius, color)
	draw_arc(Vector2.ZERO, radius, 0, TAU, 32, Color(1,1,1,0.8), 2)
