extends CharacterBody2D

@export var speed = 300.0
@export var acceleration = 30.0
@export var friction = 10.0
@export var jump_height = 500.0
@export var jump_force_radius = 300.0
@export var jump_force_strength = 300.0

var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")

func _ready():
	if $ColorRect:
		var shader_code = """
shader_type canvas_item;
void fragment() {
	vec2 center = vec2(0.5, 0.5);
	float dist = distance(UV, center);
	float circle = smoothstep(0.5, 0.48, dist);
	COLOR.a *= circle;
}
"""
		var shader = Shader.new()
		shader.code = shader_code
		
		var material = ShaderMaterial.new()
		material.shader = shader
		
		$ColorRect.material = material

func _physics_process(delta):
	if not is_on_floor():
		velocity.y += gravity * delta
	
	if Input.is_action_just_pressed("ui_accept"):
		velocity.y = -jump_height
		emit_jump_force()
	
	var direction = Input.get_axis("ui_left", "ui_right")
	
	if direction:
		velocity.x = move_toward(velocity.x, direction * speed, acceleration)
	else:
		velocity.x = move_toward(velocity.x, 0, friction)
	
	move_and_slide()

func emit_jump_force():
	print("Emitting jump force from: ", global_position)
	var blocks = get_tree().get_nodes_in_group("destructible_blocks")
	
	for block in blocks:
		var distance = global_position.distance_to(block.global_position)
		
		if distance <= jump_force_radius:
			var force_factor = 1.0 - (distance / jump_force_radius)
			var force = jump_force_strength * force_factor
			block.receive_force(global_position, force)

func create_force_wave_effect():
	var circle = Node2D.new()
	get_parent().add_child(circle)
	circle.global_position = global_position
	
	circle.set_script(load("res://force_wave_effect.gd"))
	
	var script_text = """
extends Node2D

var radius = 10.0
var max_radius = 100.0
var speed = 200.0
var color = Color(0.2, 0.5, 1.0, 0.5)

func _process(delta):
	radius += speed * delta
	queue_redraw()
	
	if radius >= max_radius:
		queue_free()

func _draw():
	draw_circle(Vector2.ZERO, radius, color)
	draw_arc(Vector2.ZERO, radius, 0, TAU, 32, Color(1,1,1,0.8), 2)
"""
	
	var file = FileAccess.open("res://force_wave_effect.gd", FileAccess.WRITE)
	file.store_string(script_text)
	file = null
