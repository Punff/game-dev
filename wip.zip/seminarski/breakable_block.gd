extends Node2D

@export_range(0.0001, 0.01) var fragment_density: float = 0.001
@export_range(4, 16) var min_fragments: int = 6
@export_range(16, 100) var max_fragments: int = 50
@export var block_color: Color = Color(0.8, 0.4, 0.2)
@export var edge_color: Color = Color(0.6, 0.3, 0.15)
@export var gravity_scale: float = 0.01
@export var break_threshold: float = 100.0
@export var destruction_timeout: float = 60.0
@export var fragment_collision_layer: int = 1
@export var block_size: Vector2 = Vector2(64, 64)

var _rng = RandomNumberGenerator.new()
var fragments = []
var regions = []
var block_active = true
var fragment_count = 16
var broken_regions = []  # Track regions that have already been broken

func _ready():
	_rng.randomize()
	add_to_group("destructible_blocks")
	calculate_fragment_count()
	var block = create_block()
	add_child(block)
	generate_voronoi_regions()

func calculate_fragment_count():
	var area = block_size.x * block_size.y
	var calculated_fragments = int(area * fragment_density)
	fragment_count = clamp(calculated_fragments, min_fragments, max_fragments)
	print("Block size: ", block_size, " Area: ", area, " Fragment count: ", fragment_count)

func create_block():
	var block = StaticBody2D.new()
	block.name = "Block"
	
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = block_size
	collision.shape = shape
	block.add_child(collision)
	
	var visual = ColorRect.new()
	visual.size = block_size
	visual.position = -block_size / 2
	visual.color = block_color
	block.add_child(visual)
	
	return block

func generate_voronoi_regions():
	var points = []
	var columns = ceil(sqrt(fragment_count * block_size.x / block_size.y))
	var rows = ceil(fragment_count / float(columns))
	var cell_width = block_size.x / columns
	var cell_height = block_size.y / rows
	
	for i in range(rows):
		for j in range(columns):
			if points.size() >= fragment_count:
				break
				
			var point = Vector2(
				-block_size.x/2 + j * cell_width + _rng.randf() * cell_width,
				-block_size.y/2 + i * cell_height + _rng.randf() * cell_height
			)
			points.append(point)
	
	var block_corners = [
		Vector2(-block_size.x/2, -block_size.y/2),
		Vector2(block_size.x/2, -block_size.y/2),
		Vector2(block_size.x/2, block_size.y/2),
		Vector2(-block_size.x/2, block_size.y/2)
	]
	
	calculate_regions(points, block_corners)

func calculate_regions(points, block_corners):
	for i in range(points.size()):
		var region = []
		var center = points[i]
		
		var area = block_size.x * block_size.y
		var avg_fragment_area = area / fragment_count
		var approximate_radius = sqrt(avg_fragment_area / PI) * 1.5
		
		var num_vertices = _rng.randi_range(5, 8)
		for j in range(num_vertices):
			var angle = TAU * j / num_vertices
			var radius_variation = _rng.randf_range(0.8, 1.2)
			var point = center + Vector2(cos(angle), sin(angle)) * approximate_radius * radius_variation
			
			point.x = clamp(point.x, -block_size.x/2, block_size.x/2)
			point.y = clamp(point.y, -block_size.y/2, block_size.y/2)
			
			region.append(point)
		
		region.sort_custom(func(a, b): 
			return atan2(a.y - center.y, a.x - center.x) < atan2(b.y - center.y, b.x - center.x)
		)
		
		if region.size() >= 3:
			regions.append({
				"points": region,
				"center": center,
				"id": i  # Add a unique ID to each region
			})

func receive_force(force_origin, force_strength):
	# Handle case when everything is gone
	if regions.is_empty() and fragments.is_empty():
		return
		
	print("Block received force: ", force_strength, " from ", force_origin)
	
	# Try to break the block if force is strong enough
	if force_strength >= break_threshold:
		break_apart_at_location(force_origin, force_strength)
	
	# Always apply force to existing fragments regardless of whether the block broke
	apply_force_to_fragments(force_origin, force_strength)

func break_apart_at_location(force_origin, force_strength):
	# If there are no regions left to break, exit
	if regions.is_empty():
		return
		
	var affected_regions = []
	var remaining_regions = []
	var force_radius = 100.0
	
	for node in get_tree().get_nodes_in_group("player"):
		if node.has_method("get_jump_force_radius"):
			force_radius = node.get_jump_force_radius()
		elif node.has_property("jump_force_radius"):
			force_radius = node.jump_force_radius
		break
	
	var local_force_origin = to_local(force_origin)
	
	# Analyze which regions are affected by the force
	for region in regions:
		var distance = region.center.distance_to(local_force_origin)
		if distance <= force_radius:
			affected_regions.append(region)
		else:
			remaining_regions.append(region)
	
	# If no regions are affected, don't do anything
	if affected_regions.size() == 0:
		return
		
	# Remove the current block representation (whether original or remaining)
	if block_active:
		var original_block = $Block
		if original_block:
			original_block.queue_free()
			block_active = false
	else:
		var remaining_block = get_node_or_null("RemainingBlock")
		if remaining_block:
			remaining_block.queue_free()
	
	# Create new remaining block with unaffected regions
	if remaining_regions.size() > 0:
		create_remaining_block(remaining_regions)
	
	# Create fragments for affected regions
	for region in affected_regions:
		# Only create fragments for regions that haven't been broken before
		if not region_already_broken(region):
			create_fragment(region.points, force_origin, force_strength)
			broken_regions.append(region.id)  # Mark as broken
		
	# Remove affected regions from the list
	for region in affected_regions:
		regions.erase(region)

# Check if a region has already been broken
func region_already_broken(region):
	return region.id in broken_regions

# Apply forces to all existing fragments
func apply_force_to_fragments(force_origin, force_strength):
	for fragment in fragments:
		if is_instance_valid(fragment):
			var fragment_center = fragment.global_position
			var direction = (fragment_center - force_origin).normalized()
			var distance = fragment_center.distance_to(force_origin)
			
			# Only affect fragments within a reasonable range
			var force_radius = 100.0
			if distance <= force_radius:
				var force_factor = 1.0 - clamp(distance / force_radius, 0.0, 1.0)
				# Apply reduced force for stability
				var impulse = direction * force_strength * force_factor * 0.5
				fragment.apply_central_impulse(impulse)

func create_remaining_block(remaining_regions):
	# Remove any existing remaining block
	var existing = get_node_or_null("RemainingBlock")
	if existing:
		existing.queue_free()
	
	var static_block = StaticBody2D.new()
	static_block.name = "RemainingBlock"
	add_child(static_block)
	
	for region in remaining_regions:
		var shape = CollisionPolygon2D.new()
		shape.polygon = region.points
		static_block.add_child(shape)
		
		var visual = Polygon2D.new()
		visual.polygon = region.points
		visual.color = block_color
		static_block.add_child(visual)
		
		var line = Line2D.new()
		line.points = region.points + [region.points[0]]
		line.width = 1.0
		line.default_color = edge_color
		static_block.add_child(line)

func create_fragment(points, force_origin, force_strength):
	var fragment = RigidBody2D.new()
	fragment.gravity_scale = gravity_scale
	fragment.mass = _rng.randf_range(0.5, 2.0)
	fragment.collision_layer = fragment_collision_layer
	fragment.collision_mask = 1  # Allow collision with player (layer 1)
	
	# Make fragments more responsive to external forces
	fragment.contact_monitor = true
	fragment.max_contacts_reported = 4
	fragment.can_sleep = false  # Prevent fragments from "sleeping" in physics engine
	fragment.linear_damp = 0.2  # Add some damping for stability
	
	var collision = CollisionPolygon2D.new()
	collision.polygon = points
	fragment.add_child(collision)
	
	var polygon = Polygon2D.new()
	polygon.polygon = points
	polygon.color = block_color
	polygon.name = "Polygon2D"
	
	var line = Line2D.new()
	line.points = points + [points[0]]
	line.width = 1.0
	line.default_color = edge_color
	
	fragment.add_child(polygon)
	fragment.add_child(line)
	
	add_child(fragment)
	fragments.append(fragment)
	
	var fragment_center = get_polygon_center(points)
	var direction = (to_global(fragment_center) - force_origin).normalized()
	var distance = to_global(fragment_center).distance_to(force_origin)
	var force_factor = 1.0 - clamp(distance / 100.0, 0.0, 1.0)
	var impulse = direction * force_strength * force_factor
	
	fragment.angular_velocity = _rng.randf_range(-5, 5)
	fragment.apply_central_impulse(impulse)
	
	var timer = Timer.new()
	timer.wait_time = destruction_timeout
	timer.one_shot = true
	timer.autostart = true
	fragment.add_child(timer)
	
	timer.timeout.connect(func(): fade_out_fragment(fragment))

func fade_out_fragment(fragment):
	var tween = create_tween()
	var polygon = fragment.get_node("Polygon2D")
	if polygon:
		tween.tween_property(polygon, "modulate", Color(1, 1, 1, 0), 1.0)
	
	await tween.finished
	
	fragments.erase(fragment)
	fragment.queue_free()
	
	if fragments.is_empty() and regions.is_empty():
		queue_free()

func get_polygon_center(points):
	var sum = Vector2.ZERO
	for point in points:
		sum += point
	return sum / points.size()

func _property_list_changed():
	calculate_fragment_count()
	
	if Engine.is_editor_hint():
		for child in get_children():
			child.queue_free()
		
		var block = create_block()
		add_child(block)
