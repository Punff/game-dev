extends Node2D

@export var block_color = Color(0.7, 0.7, 0.7)
@export var fragment_count = 8
@export var show_fragment_outlines = true
@export var break_threshold = 100.0
@export var fragment_force = 0.5  # Small force

var fragments = []
var broken = false
var force_accumulated = 0.0
var block_size = Vector2.ZERO

func _ready():
	add_to_group("destructible_blocks")
	
	# Get size from Area2D if it exists
	var area = get_node_or_null("BlockArea")
	if area != null:
		var collision_shape = area.get_node_or_null("CollisionShape2D")
		if collision_shape and collision_shape.shape is RectangleShape2D:
			block_size = collision_shape.shape.size
		elif collision_shape and collision_shape.shape is CircleShape2D:
			block_size = Vector2(collision_shape.shape.radius * 2, collision_shape.shape.radius * 2)
	else:
		# Default size
		block_size = Vector2(64, 64)
		
		# Create Area2D
		area = Area2D.new()
		area.name = "BlockArea"
		add_child(area)
		
		# Add shape
		var area_collision = CollisionShape2D.new()
		var area_shape = RectangleShape2D.new()
		area_shape.size = block_size
		area_collision.shape = area_shape
		area.add_child(area_collision)
	
	# Create StaticBody2D for collision
	var body = StaticBody2D.new()
	body.name = "StaticBody"
	add_child(body)
	
	# Add collision shape
	var body_collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = block_size
	body_collision.shape = shape
	body.add_child(body_collision)
	
	# Create visible block
	add_visible_block()
	
	# Generate fragment data
	generate_fragment_data()

func add_visible_block():
	# Add visible block shape
	var visible_block = Polygon2D.new()
	visible_block.name = "VisibleBlock"
	add_child(visible_block)
	visible_block.color = block_color
	
	# Create rectangle shape
	var corners = [
		Vector2(-block_size.x/2, -block_size.y/2),
		Vector2(block_size.x/2, -block_size.y/2),
		Vector2(block_size.x/2, block_size.y/2),
		Vector2(-block_size.x/2, block_size.y/2)
	]
	visible_block.polygon = corners
	
	# Add outline if enabled
	if show_fragment_outlines:
		var outline = Line2D.new()
		outline.name = "BlockOutline"
		add_child(outline)
		var outline_points = corners.duplicate()
		outline_points.append(outline_points[0])  # Close the loop
		outline.points = outline_points
		outline.width = 2.0
		outline.default_color = Color(0, 0, 0, 0.5)

func generate_fragment_data():
	# Store fragment data for later creation
	var fragment_data = []
	
	# Block boundaries
	var corners = [
		Vector2(-block_size.x/2, -block_size.y/2),
		Vector2(block_size.x/2, -block_size.y/2),
		Vector2(block_size.x/2, block_size.y/2),
		Vector2(-block_size.x/2, block_size.y/2)
	]
	
	# Generate seed points
	var seed_points = []
	for i in range(fragment_count):
		seed_points.append(Vector2(
			randf_range(-block_size.x/2, block_size.x/2),
			randf_range(-block_size.y/2, block_size.y/2)
		))
	
	# Generate fragment shapes
	for i in range(seed_points.size()):
		var polygon_points = generate_voronoi_cell(seed_points[i], seed_points, corners)
		
		# Store the data
		fragment_data.append({
			"seed_point": seed_points[i],
			"polygon": polygon_points
		})
	
	# Store the data for later
	set_meta("fragment_data", fragment_data)

func generate_voronoi_cell(seed_point, all_seeds, boundaries):
	var points = []
	var max_radius = max(block_size.x, block_size.y) * 2
	
	# Generate rays in multiple directions
	for i in range(16):  # 16 directions for smooth polygons
		var angle = i * 2 * PI / 16
		var direction = Vector2(cos(angle), sin(angle))
		var ray_end = seed_point + direction * max_radius
		
		# Find closest intersection
		var closest_dist = max_radius
		var closest_point = ray_end
		
		# Check block boundaries
		for j in range(boundaries.size()):
			var line_start = boundaries[j]
			var line_end = boundaries[(j + 1) % boundaries.size()]
			
			var intersection = ray_line_intersection(seed_point, ray_end, line_start, line_end)
			if intersection:
				var dist = seed_point.distance_to(intersection)
				if dist < closest_dist:
					closest_dist = dist
					closest_point = intersection
		
		# Check against other cells
		for other_seed in all_seeds:
			if other_seed == seed_point:
				continue
			
			# Create boundary between cells
			var midpoint = (seed_point + other_seed) / 2
			var normal = (other_seed - seed_point).normalized().rotated(PI/2)
			var boundary_start = midpoint - normal * max_radius
			var boundary_end = midpoint + normal * max_radius
			
			var intersection = ray_line_intersection(seed_point, ray_end, boundary_start, boundary_end)
			if intersection:
				var dist = seed_point.distance_to(intersection)
				if dist < closest_dist:
					closest_dist = dist
					closest_point = intersection
		
		points.append(closest_point)
	
	return points

func receive_force(source_pos, force_amount):
	force_accumulated += force_amount
	
	if force_accumulated >= break_threshold and not broken:
		break_block(source_pos)

func break_block(impact_pos):
	if broken:
		return
	
	broken = true
	
	# Create a container for all fragments
	var container = Node2D.new()
	container.name = "Fragments"
	container.position = Vector2.ZERO  # Important: Position at 0,0
	add_child(container)
	
	# Get the fragment data
	var fragment_data = get_meta("fragment_data")
	
	# Create all fragments using the SAME POSITION as the block
	for data in fragment_data:
		create_fragment(container, data.polygon)
	
	# Remove the visible block only after fragments are created
	var visible_block = get_node_or_null("VisibleBlock")
	if visible_block:
		visible_block.queue_free()
	
	var block_outline = get_node_or_null("BlockOutline")
	if block_outline:
		block_outline.queue_free()
	
	for child in get_children():
		if child is StaticBody2D and child.name == "StaticBody":
			child.queue_free()
	
	# After creating all fragments with exactly matching positions,
	# apply very minimal forces to show they're separate
	for fragment in fragments:
		apply_minimal_forces(fragment, impact_pos)

func create_fragment(parent, polygon_points):
	var fragment = RigidBody2D.new()
	parent.add_child(fragment)
	fragments.append(fragment)
	
	# IMPORTANT: Position at exactly 0,0 relative to parent
	fragment.position = Vector2.ZERO
	
	# Configure physics to minimize movement
	fragment.gravity_scale = 0.01
	fragment.linear_damp = 0.95
	fragment.angular_damp = 0.95
	fragment.continuous_cd = RigidBody2D.CCD_MODE_CAST_RAY  # Prevent tunneling
	
	# Create visual polygon
	var poly = Polygon2D.new()
	fragment.add_child(poly)
	poly.polygon = polygon_points
	poly.color = block_color.lightened(randf_range(-0.1, 0.1))
	
	# Add collision
	var collision = CollisionPolygon2D.new()
	collision.polygon = polygon_points
	fragment.add_child(collision)
	
	# Add extremely thin outline
	if show_fragment_outlines:
		var outline = Line2D.new()
		fragment.add_child(outline)
		var outline_points = polygon_points.duplicate()
		outline_points.append(outline_points[0])
		outline.points = outline_points
		outline.width = 0.3  # Very thin outline
		outline.default_color = Color(0, 0, 0, 0.3)  # Very subtle

func apply_minimal_forces(fragment, impact_pos):
	# Calculate fragment center in global coordinates
	var fragment_center = fragment.global_position
	for child in fragment.get_children():
		if child is Polygon2D:
			var centroid = Vector2.ZERO
			for point in child.polygon:
				centroid += point
			centroid /= child.polygon.size()
			fragment_center = fragment.global_position + centroid
			break
	
	# Direction from impact to fragment
	var direction = (fragment_center - impact_pos).normalized()
	var distance = fragment_center.distance_to(impact_pos)
	var max_distance = max(block_size.x, block_size.y)
	var distance_factor = 1.0 - clamp(distance / max_distance, 0.0, 0.95)
	
	# Apply tiny force
	fragment.apply_central_impulse(direction * fragment_force * distance_factor)
	
	# Apply tiny rotation
	fragment.apply_torque(randf_range(-0.05, 0.05) * distance_factor)

func ray_line_intersection(ray_start, ray_end, line_start, line_end):
	var ray_dir = ray_end - ray_start
	var line_dir = line_end - line_start
	
	var cross_product = ray_dir.cross(line_dir)
	if abs(cross_product) < 0.0001:
		return null
		
	var t = ((line_start - ray_start).cross(line_dir)) / cross_product
	var u = ((line_start - ray_start).cross(ray_dir)) / cross_product
	
	if t >= 0 and u >= 0 and u <= 1:
		return ray_start + ray_dir * t
	
	return null
