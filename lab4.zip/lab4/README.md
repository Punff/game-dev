# AdvancedCharacter

A simple to use class that enables your CharacterBody3D to handle stairs and custom gravity direction properly.

***
### Instructions
* Use my script template to understand
* Use instead move() instead of move_and_collide()
* Use local_velocity instead of velocity