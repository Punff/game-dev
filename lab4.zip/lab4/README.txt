Please take a look at the provided example player
if you're confused on how to use this asset.
